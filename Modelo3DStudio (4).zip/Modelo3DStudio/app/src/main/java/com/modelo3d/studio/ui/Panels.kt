package com.modelo3d.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.modelo3d.studio.model.*

private fun String.toF(): Float? = replace(',', '.').toFloatOrNull()

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

/** Panel inferior azul con ✓ y ✕, como "Boceto 1" / "Extrusión 1" en Onshape. */
@Composable
private fun PanelFrame(
    title: String,
    canConfirm: Boolean,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)) {
        Row(
            Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(CadColors.GoldLight, CadColors.GoldDeep))).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, Modifier.weight(1f), color = CadColors.OnGold, style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onConfirm, enabled = canConfirm) {
                Icon(Icons.Default.Check, "Aceptar", tint = if (canConfirm) CadColors.OnGold else Color(0x661A1405))
            }
            IconButton(onClick = onCancel) { Icon(Icons.Default.Close, "Cancelar", tint = CadColors.OnGold) }
        }
        Column(Modifier.padding(12.dp), content = content)
    }
}

@Composable
fun SketchPanel(
    draft: SketchOp,
    isNew: Boolean,
    toolName: String?,
    hint: String,
    canFinish: Boolean,
    onTools: () -> Unit,
    onUndoShape: () -> Unit,
    onFinish: () -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    PanelFrame(draft.name, draft.shapes.isNotEmpty(), onConfirm, onCancel, modifier) {
        Text(
            "Plano: ${planeLabel(draft.plane)} · ${draft.shapes.size} elementos",
            style = MaterialTheme.typography.labelLarge
        )
        Text(
            if (toolName != null) "$toolName: $hint" else hint,
            color = CadColors.TextDim, fontSize = 13.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = onTools) { Text("Herramientas") }
            OutlinedButton(onClick = onUndoShape, enabled = draft.shapes.isNotEmpty()) { Text("Quitar último") }
            if (canFinish) OutlinedButton(onClick = onFinish) { Text("Terminar trazo") }
        }
        if (!isNew) TextButton(onClick = onDelete) { Text("Eliminar boceto") }
    }
}

@Composable
fun DimDialog(shape: Shape, onApply: (Shape) -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit) {
    var f1 by remember(shape) {
        mutableStateOf(
            when (shape) {
                is RectS -> fmt(shape.w)
                is CircleS -> fmt(shape.r)
                is LineS -> fmt(dist(shape.a, shape.b))
                is ArcS -> ""
            }
        )
    }
    var f2 by remember(shape) { mutableStateOf(if (shape is RectS) fmt(shape.h) else "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cota") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (shape) {
                    is RectS -> {
                        NumberField("Ancho (cm)", f1, { f1 = it }, Modifier.fillMaxWidth())
                        NumberField("Alto (cm)", f2, { f2 = it }, Modifier.fillMaxWidth())
                    }
                    is CircleS -> NumberField("Radio (cm)", f1, { f1 = it }, Modifier.fillMaxWidth())
                    is LineS -> NumberField("Longitud (cm)", f1, { f1 = it }, Modifier.fillMaxWidth())
                    is ArcS -> Text("Los arcos aún no se pueden acotar.")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = f1.toF()
                val b = f2.toF()
                val out: Shape? = when (shape) {
                    is RectS -> if (a != null && b != null && a > 0f && b > 0f) shape.copy(w = a, h = b) else null
                    is CircleS -> if (a != null && a > 0f) shape.copy(r = a) else null
                    is LineS -> {
                        val len = dist(shape.a, shape.b)
                        if (a != null && a > 0f && len > 1e-6f) {
                            val k = a / len
                            shape.copy(
                                b = Pt(
                                    shape.a.u + (shape.b.u - shape.a.u) * k,
                                    shape.a.v + (shape.b.v - shape.a.v) * k
                                )
                            )
                        } else null
                    }
                    is ArcS -> null
                }
                if (out != null) onApply(out)
            }) { Text("Aplicar") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Eliminar") }
                TextButton(onClick = onDismiss) { Text("Cerrar") }
            }
        }
    )
}

@Composable
fun ExtrudePanel(
    draft: ExtrudeOp,
    sketchName: String,
    isNew: Boolean,
    onChange: (ExtrudeOp) -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var depth by remember(draft.id) { mutableStateOf(fmt(draft.depth)) }
    val dv = depth.toF()

    PanelFrame(draft.name, dv != null && dv > 0f, onConfirm, onCancel, modifier) {
        Text("Boceto: $sketchName", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        NumberField("Profundidad (cm)", depth, {
            depth = it
            it.toF()?.let { v -> onChange(draft.copy(depth = v)) }
        }, Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Dirección opuesta", Modifier.weight(1f))
            Switch(checked = draft.reverse, onCheckedChange = { onChange(draft.copy(reverse = it)) })
        }
        if (!isNew) TextButton(onClick = onDelete) { Text("Eliminar extrusión") }
    }
}
