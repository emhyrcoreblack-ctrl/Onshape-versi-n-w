package com.modelo3d.studio.model

import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/** Punto/vector 3D. Convención CAD: X derecha, Y profundidad, Z arriba. Unidades: cm. */
data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(k: Float) = V3(x * k, y * k, z * k)
    operator fun unaryMinus() = V3(-x, -y, -z)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun length() = sqrt(dot(this))
    fun normalized(): V3 {
        val l = length()
        return if (l < 1e-9f) this else this * (1f / l)
    }
}

val PLANES = listOf("Top", "Front", "Right")

fun planeLabel(name: String): String = when {
    name == "Top" -> "Superior (XY)"
    name == "Front" -> "Frontal (XZ)"
    name == "Right" -> "Derecho (YZ)"
    else -> "Cara de pieza"
}

/** Plano con origen o, ejes u y v (en el plano) y normal n. */
class PlaneDef(val o: V3, val u: V3, val v: V3, val n: V3)

private val planeCache = HashMap<String, PlaneDef>()

/** Marco de un plano a partir de su normal: u siempre horizontal, v "hacia arriba". */
fun frameFromNormal(o: V3, n0: V3): PlaneDef {
    val n = n0.normalized()
    val up = if (abs(n.z) < 0.9f) V3(0f, 0f, 1f) else V3(0f, 1f, 0f)
    val u = up.cross(n).normalized()
    val v = n.cross(u)
    return PlaneDef(o, u, v, n)
}

/** Clave de texto de un plano creado sobre la cara de una pieza. */
fun facePlaneKey(o: V3, n: V3): String =
    String.format(Locale.US, "F|%.4f,%.4f,%.4f|%.4f,%.4f,%.4f", o.x, o.y, o.z, n.x, n.y, n.z)

private fun parseV(s: String): V3 {
    val p = s.split(",")
    return V3(p[0].toFloat(), p[1].toFloat(), p[2].toFloat())
}

fun planeDef(plane: String): PlaneDef {
    planeCache[plane]?.let { return it }
    val zero = V3(0f, 0f, 0f)
    val d = when {
        plane == "Front" -> PlaneDef(zero, V3(1f, 0f, 0f), V3(0f, 0f, 1f), V3(0f, -1f, 0f))
        plane == "Right" -> PlaneDef(zero, V3(0f, 1f, 0f), V3(0f, 0f, 1f), V3(1f, 0f, 0f))
        plane.startsWith("F|") -> {
            val parts = plane.split("|")
            frameFromNormal(parseV(parts[1]), parseV(parts[2]))
        }
        else -> PlaneDef(zero, V3(1f, 0f, 0f), V3(0f, 1f, 0f), V3(0f, 0f, 1f))
    }
    planeCache[plane] = d
    return d
}

/** Punto 3D desde coordenadas (u,v) del plano y un desplazamiento n sobre su normal. */
fun planePoint(plane: String, u: Float, v: Float, n: Float = 0f): V3 {
    val d = planeDef(plane)
    return d.o + d.u * u + d.v * v + d.n * n
}

/** Vector (sin origen) en las coordenadas del plano. */
fun planeVec(plane: String, u: Float, v: Float, n: Float = 0f): V3 {
    val d = planeDef(plane)
    return d.u * u + d.v * v + d.n * n
}

/** Línea o lazo 3D (contorno de un boceto). */
class Poly3(val pts: List<V3>, val closed: Boolean)

fun shapePolys(plane: String, shapes: List<Shape>): List<Poly3> = shapes.map { s ->
    val (pts, closed) = outline2D(s)
    Poly3(pts.map { planePoint(plane, it.u, it.v, 0f) }, closed)
}

/** Cotas que se muestran junto a las figuras. */
fun shapeLabels(plane: String, shapes: List<Shape>): List<Pair<V3, String>> {
    val out = ArrayList<Pair<V3, String>>()
    for (s in shapes) {
        when (s) {
            is LineS -> out.add(
                planePoint(plane, (s.a.u + s.b.u) / 2f, (s.a.v + s.b.v) / 2f, 0f) to fmt(dist(s.a, s.b))
            )
            is RectS -> {
                out.add(planePoint(plane, s.x + s.w / 2f, s.y, 0f) to fmt(s.w))
                out.add(planePoint(plane, s.x + s.w, s.y + s.h / 2f, 0f) to fmt(s.h))
            }
            is CircleS -> out.add(planePoint(plane, s.c.u + s.r, s.c.v, 0f) to ("R" + fmt(s.r)))
            is ArcS -> {}
        }
    }
    return out
}

/** Arista real del sólido: entre dos vértices y las caras que une (f2 = -1 si solo toca una). */
class Edge(val a: Int, val b: Int, val f1: Int, val f2: Int)

/** Sólido de caras planas: mallas, normales hacia afuera, triángulos y propiedades. */
class Solid(
    val name: String,
    val verts: List<V3>,
    val faces: List<IntArray>,
    val normals: List<V3>,
    val tris: List<IntArray>,
    val edges: List<Edge>,
    val selectable: List<Boolean>,
    val volume: Float,
    val area: Float,
    val opId: String = ""
)

/** Extruye un perfil cerrado (antihorario en u,v) a lo largo de la normal del plano. */
fun extrudeProfile(
    plane: String, poly: List<Pt>, depth: Float, reverse: Boolean, name: String, opId: String
): Solid {
    val n = poly.size
    val d = if (reverse) -depth else depth
    val off = planeVec(plane, 0f, 0f, d)
    val base = poly.map { planePoint(plane, it.u, it.v, 0f) }
    val top = base.map { it + off }
    val verts = base + top
    val sgn = if (d >= 0f) 1f else -1f
    val nTop = planeVec(plane, 0f, 0f, sgn)
    val faces = ArrayList<IntArray>()
    val normals = ArrayList<V3>()
    val tris = ArrayList<IntArray>()

    fun addTri(a: Int, b: Int, c: Int, out: V3) {
        val t = (verts[b] - verts[a]).cross(verts[c] - verts[a])
        if (t.dot(out) < 0f) tris.add(intArrayOf(a, c, b)) else tris.add(intArrayOf(a, b, c))
    }

    // Tapas
    faces.add(IntArray(n) { it }); normals.add(-nTop)
    faces.add(IntArray(n) { n + it }); normals.add(nTop)
    for (t in triangulate(poly)) {
        addTri(t[0], t[1], t[2], -nTop)
        addTri(n + t[0], n + t[1], n + t[2], nTop)
    }
    // Caras laterales
    for (i in 0 until n) {
        val j = (i + 1) % n
        val du = poly[j].u - poly[i].u
        val dv = poly[j].v - poly[i].v
        val len = hypot(du, dv)
        val out = if (len < 1e-9f) nTop else planeVec(plane, dv / len, -du / len, 0f)
        faces.add(intArrayOf(i, j, n + j, n + i)); normals.add(out)
        addTri(i, j, n + j, out)
        addTri(i, n + j, n + i, out)
    }
    // Aristas reales: bordes de las tapas y esquinas marcadas (no las facetas de superficies curvas)
    val edges = ArrayList<Edge>()
    for (i in 0 until n) {
        val j = (i + 1) % n
        edges.add(Edge(i, j, 0, 2 + i))
        edges.add(Edge(n + i, n + j, 1, 2 + i))
        val prev = (i + n - 1) % n
        if (normals[2 + prev].dot(normals[2 + i]) < 0.866f) {
            edges.add(Edge(i, n + i, 2 + prev, 2 + i))
        }
    }
    // Caras donde se puede dibujar: tapas y lados planos entre esquinas marcadas (no facetas curvas)
    val sharp = BooleanArray(n) { i -> normals[2 + (i + n - 1) % n].dot(normals[2 + i]) < 0.866f }
    val selectable = ArrayList<Boolean>()
    selectable.add(true)
    selectable.add(true)
    for (i in 0 until n) selectable.add(sharp[i] && sharp[(i + 1) % n])
    val a2 = abs(signedArea(poly))
    var per = 0f
    for (i in 0 until n) per += dist(poly[i], poly[(i + 1) % n])
    return Solid(name, verts, faces, normals, tris, edges, selectable, a2 * abs(d), 2f * a2 + per * abs(d), opId)
}

fun buildSolids(ops: List<Op>): List<Solid> {
    val sketches = ops.filterIsInstance<SketchOp>().associateBy { it.id }
    val out = ArrayList<Solid>()
    for (e in ops.filterIsInstance<ExtrudeOp>()) {
        val s = sketches[e.sketchId] ?: continue
        if (e.depth <= 0f) continue
        for (poly in profiles(s.shapes)) {
            out.add(extrudeProfile(s.plane, poly, e.depth, e.reverse, "Part ${out.size + 1}", e.id))
        }
    }
    return out
}

fun sceneExtent(solids: List<Solid>, outlines: List<List<V3>>): Float {
    var m = 0f
    fun see(p: V3) { m = max(m, max(abs(p.x), max(abs(p.y), abs(p.z)))) }
    solids.forEach { s -> s.verts.forEach { see(it) } }
    outlines.forEach { o -> o.forEach { see(it) } }
    return m
}

/** Formato corto: 20 -> "20", 4.85 -> "4.85". */
fun fmt(f: Float): String =
    if (abs(f - Math.round(f)) < 1e-4f) Math.round(f).toString()
    else String.format(Locale.US, "%.3f", f).trimEnd('0').trimEnd('.')

private fun num(v: Float) = String.format(Locale.US, "%.5f", v)

/** STL ASCII en milímetros (el modelo está en cm). */
fun exportStl(solids: List<Solid>): String {
    val sb = StringBuilder()
    for (s in solids) {
        val nm = s.name.replace(' ', '_')
        sb.append("solid ").append(nm).append('\n')
        for (t in s.tris) {
            val a = s.verts[t[0]]
            val b = s.verts[t[1]]
            val c = s.verts[t[2]]
            val n = (b - a).cross(c - a).normalized()
            sb.append(" facet normal ${num(n.x)} ${num(n.y)} ${num(n.z)}\n  outer loop\n")
            for (p in listOf(a, b, c)) {
                sb.append("   vertex ${num(p.x * 10f)} ${num(p.y * 10f)} ${num(p.z * 10f)}\n")
            }
            sb.append("  endloop\n endfacet\n")
        }
        sb.append("endsolid ").append(nm).append('\n')
    }
    return sb.toString()
}

/** Dimensiones de la caja envolvente de todas las piezas (cm). */
fun sizeOf(solids: List<Solid>): V3? {
    if (solids.isEmpty()) return null
    val all = solids.flatMap { it.verts }
    return V3(
        all.maxOf { it.x } - all.minOf { it.x },
        all.maxOf { it.y } - all.minOf { it.y },
        all.maxOf { it.z } - all.minOf { it.z }
    )
}

fun volumeOf(s: Solid): Float = s.volume

fun areaOf(s: Solid): Float = s.area

/** Cota lista para dibujar: puntos medidos a-b, direccion hacia donde se separa y su texto. */
class DimDraw(
    val a: V3, val b: V3, val dir: V3, val text: String, val selected: Boolean, val radial: Boolean
)

fun shapeDims(plane: String, shapes: List<Shape>, sel: DimRef?): List<DimDraw> {
    val out = ArrayList<DimDraw>()
    fun p3(p: Pt) = planePoint(plane, p.u, p.v, 0f)
    shapes.forEachIndexed { i, s ->
        fun isSel(w: Int) = sel != null && sel.index == i && sel.which == w
        when (s) {
            is LineS -> {
                val len = dist(s.a, s.b)
                if (len > 1e-4f) {
                    val nu = -(s.b.v - s.a.v) / len
                    val nv = (s.b.u - s.a.u) / len
                    out.add(DimDraw(p3(s.a), p3(s.b), planeVec(plane, nu, nv), fmt(len), isSel(0), false))
                }
            }
            is RectS -> {
                out.add(
                    DimDraw(
                        p3(Pt(s.x, s.y + s.h)), p3(Pt(s.x + s.w, s.y + s.h)),
                        planeVec(plane, 0f, 1f), fmt(s.w), isSel(0), false
                    )
                )
                out.add(
                    DimDraw(
                        p3(Pt(s.x + s.w, s.y)), p3(Pt(s.x + s.w, s.y + s.h)),
                        planeVec(plane, 1f, 0f), fmt(s.h), isSel(1), false
                    )
                )
            }
            is CircleS -> {
                val q = Pt(s.c.u + s.r * 0.7071f, s.c.v + s.r * 0.7071f)
                out.add(DimDraw(p3(s.c), p3(q), V3(0f, 0f, 0f), "R" + fmt(s.r), isSel(0), true))
            }
            is ArcS -> {}
        }
    }
    return out
}
