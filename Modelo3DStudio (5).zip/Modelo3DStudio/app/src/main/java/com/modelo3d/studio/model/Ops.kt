package com.modelo3d.studio.model

import org.json.JSONArray
import org.json.JSONObject

/** Operación del árbol paramétrico (como el panel "Operaciones" de Onshape). */
sealed interface Op {
    val id: String
    val name: String
}

data class SketchOp(
    override val id: String,
    override val name: String,
    val plane: String,
    val shapes: List<Shape>
) : Op

data class ExtrudeOp(
    override val id: String,
    override val name: String,
    val sketchId: String,
    val depth: Float,
    val reverse: Boolean
) : Op

fun List<Op>.upserted(op: Op): List<Op> {
    val i = indexOfFirst { it.id == op.id }
    return if (i < 0) this + op else toMutableList().also { it[i] = op }
}

private fun Pt.toJ(): JSONArray = JSONArray().put(u.toDouble()).put(v.toDouble())
private fun jPt(a: JSONArray) = Pt(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())

private fun Shape.toJson(): JSONObject = when (this) {
    is LineS -> JSONObject().put("t", "line").put("a", a.toJ()).put("b", b.toJ())
    is RectS -> JSONObject().put("t", "rect").put("x", x.toDouble()).put("y", y.toDouble())
        .put("w", w.toDouble()).put("h", h.toDouble())
    is CircleS -> JSONObject().put("t", "circle").put("c", c.toJ()).put("r", r.toDouble())
    is ArcS -> JSONObject().put("t", "arc").put("a", a.toJ()).put("m", m.toJ()).put("c", c.toJ())
}

private fun shapeFromJson(o: JSONObject): Shape? = when (o.optString("t")) {
    "line" -> LineS(jPt(o.getJSONArray("a")), jPt(o.getJSONArray("b")))
    "rect" -> RectS(
        o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
        o.getDouble("w").toFloat(), o.getDouble("h").toFloat()
    )
    "circle" -> CircleS(jPt(o.getJSONArray("c")), o.getDouble("r").toFloat())
    "arc" -> ArcS(jPt(o.getJSONArray("a")), jPt(o.getJSONArray("m")), jPt(o.getJSONArray("c")))
    else -> null
}

fun Op.toJson(): JSONObject = when (this) {
    is SketchOp -> {
        val arr = JSONArray()
        shapes.forEach { arr.put(it.toJson()) }
        JSONObject().put("type", "sketch").put("id", id).put("name", name)
            .put("plane", plane).put("shapes", arr)
    }
    is ExtrudeOp -> JSONObject().put("type", "extrude").put("id", id).put("name", name)
        .put("sketchId", sketchId).put("depth", depth.toDouble()).put("reverse", reverse)
}

fun opFromJson(o: JSONObject): Op? = when (o.optString("type")) {
    "sketch" -> {
        val arr = o.optJSONArray("shapes")
        val shapes: List<Shape> = if (arr != null) {
            (0 until arr.length()).mapNotNull { shapeFromJson(arr.getJSONObject(it)) }
        } else if (o.has("w")) {
            // Formato antiguo (v0.2): un solo rectángulo
            listOf(
                RectS(
                    o.getDouble("x0").toFloat(), o.getDouble("y0").toFloat(),
                    o.getDouble("w").toFloat(), o.getDouble("h").toFloat()
                )
            )
        } else emptyList()
        SketchOp(o.getString("id"), o.getString("name"), o.getString("plane"), shapes)
    }
    "extrude" -> ExtrudeOp(
        o.getString("id"), o.getString("name"), o.getString("sketchId"),
        o.getDouble("depth").toFloat(), o.getBoolean("reverse")
    )
    else -> null
}
