# Modelo3D Studio v0.2

CAD 3D paramétrico personal para Android, inspirado en el flujo de Onshape:
**Boceto -> cotas -> Extrusión -> Piezas -> Exportar STL**.

## Qué hace
- Proyectos guardados en el teléfono (con todo su historial de operaciones).
- Visor 3D táctil: un dedo orbita, dos dedos zoom/desplazar. Vistas Frente/Arriba/Derecha/Isométrica/Ajustar.
- Boceto rectangular sobre Top/Front/Right con cotas numéricas exactas (ancho, alto, esquina).
- Extrusión con profundidad y dirección opuesta, vista previa en vivo.
- Árbol de operaciones editable: toca una operación para cambiar sus cotas; el modelo se actualiza.
- Deshacer/Rehacer, panel de Piezas, exportación a STL (mm).

## APK desde el celular
Sube `Modelo3DStudio.zip` y `.github/workflows/...yml` al repositorio, ve a Actions > Run workflow y descarga el artefacto.
