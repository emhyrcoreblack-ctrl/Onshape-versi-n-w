package com.modelo3d.studio.model

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** Punto/vector 3D. Convención CAD: X derecha, Y profundidad, Z arriba. Unidades: cm. */
data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(k: Float) = V3(x * k, y * k, z * k)
    operator fun unaryMinus() = V3(-x, -y, -z)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun length() = sqrt(dot(this))
    fun normalized(): V3 {
        val l = length()
        return if (l < 1e-9f) this else this * (1f / l)
    }
}

val PLANES = listOf("Top", "Front", "Right")

/** Punto 3D desde coordenadas (u,v) del plano y un desplazamiento n sobre su normal. */
fun planePoint(plane: String, u: Float, v: Float, n: Float = 0f): V3 = when (plane) {
    "Front" -> V3(u, -n, v)   // normal hacia el observador (-Y)
    "Right" -> V3(n, u, v)    // normal +X
    else -> V3(u, v, n)       // Top: normal +Z
}

/** Sólido de caras planas (por ahora prismas rectangulares extruidos). */
class Solid(val name: String, val verts: List<V3>, val faces: List<IntArray>) {
    val center: V3 = verts.fold(V3(0f, 0f, 0f)) { a, b -> a + b } * (1f / verts.size)

    fun faceCenter(f: IntArray): V3 =
        f.fold(V3(0f, 0f, 0f)) { a, i -> a + verts[i] } * (1f / f.size)

    /** Normal de la cara orientada hacia afuera del sólido. */
    fun faceNormal(f: IntArray): V3 {
        val a = verts[f[0]]; val b = verts[f[1]]; val c = verts[f[2]]
        val n = (b - a).cross(c - a).normalized()
        return if (n.dot(faceCenter(f) - center) < 0f) -n else n
    }
}

fun sketchOutline(s: SketchOp): List<V3> = listOf(
    planePoint(s.plane, s.x0, s.y0),
    planePoint(s.plane, s.x0 + s.w, s.y0),
    planePoint(s.plane, s.x0 + s.w, s.y0 + s.h),
    planePoint(s.plane, s.x0, s.y0 + s.h)
)

fun extrudeSolid(s: SketchOp, e: ExtrudeOp, name: String): Solid? {
    if (s.w <= 0f || s.h <= 0f || e.depth <= 0f) return null
    val d = if (e.reverse) -e.depth else e.depth
    val off = planePoint(s.plane, 0f, 0f, d)
    val base = sketchOutline(s)
    val top = base.map { it + off }
    val faces = listOf(
        intArrayOf(0, 3, 2, 1), intArrayOf(4, 5, 6, 7),
        intArrayOf(0, 1, 5, 4), intArrayOf(1, 2, 6, 5),
        intArrayOf(2, 3, 7, 6), intArrayOf(3, 0, 4, 7)
    )
    return Solid(name, base + top, faces)
}

fun buildSolids(ops: List<Op>): List<Solid> {
    val sketches = ops.filterIsInstance<SketchOp>().associateBy { it.id }
    var n = 0
    val out = ArrayList<Solid>()
    for (e in ops.filterIsInstance<ExtrudeOp>()) {
        val s = sketches[e.sketchId] ?: continue
        val solid = extrudeSolid(s, e, "Part ${n + 1}") ?: continue
        n++
        out.add(solid)
    }
    return out
}

fun sceneExtent(solids: List<Solid>, outlines: List<List<V3>>): Float {
    var m = 0f
    fun see(p: V3) { m = max(m, max(abs(p.x), max(abs(p.y), abs(p.z)))) }
    solids.forEach { s -> s.verts.forEach { see(it) } }
    outlines.forEach { o -> o.forEach { see(it) } }
    return m
}

/** Formato corto: 20 -> "20", 4.85 -> "4.85". */
fun fmt(f: Float): String =
    if (abs(f - Math.round(f)) < 1e-4f) Math.round(f).toString()
    else String.format(Locale.US, "%.3f", f).trimEnd('0').trimEnd('.')

private fun num(v: Float) = String.format(Locale.US, "%.5f", v)

/** STL ASCII en milímetros (el modelo está en cm). */
fun exportStl(solids: List<Solid>): String {
    val sb = StringBuilder()
    for (s in solids) {
        sb.append("solid ").append(s.name.replace(' ', '_')).append('\n')
        for (f in s.faces) {
            val n = s.faceNormal(f)
            for (k in 1 until f.size - 1) {
                val a = s.verts[f[0]]
                var b = s.verts[f[k]]
                var c = s.verts[f[k + 1]]
                if ((b - a).cross(c - a).dot(n) < 0f) { val t = b; b = c; c = t }
                sb.append(" facet normal ${num(n.x)} ${num(n.y)} ${num(n.z)}\n  outer loop\n")
                for (p in listOf(a, b, c)) {
                    sb.append("   vertex ${num(p.x * 10f)} ${num(p.y * 10f)} ${num(p.z * 10f)}\n")
                }
                sb.append("  endloop\n endfacet\n")
            }
        }
        sb.append("endsolid ").append(s.name.replace(' ', '_')).append('\n')
    }
    return sb.toString()
}
