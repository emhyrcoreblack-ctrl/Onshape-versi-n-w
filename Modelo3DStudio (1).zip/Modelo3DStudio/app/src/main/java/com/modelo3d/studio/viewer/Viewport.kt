package com.modelo3d.studio.viewer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import com.modelo3d.studio.model.Solid
import com.modelo3d.studio.model.V3
import com.modelo3d.studio.model.fmt
import com.modelo3d.studio.model.planePoint
import kotlin.math.max

private val LIGHT = V3(-0.35f, -0.55f, 0.75f).normalized()

private class FaceDraw(val path: Path, val depth: Float, val fill: Color)

@Composable
fun Viewport(
    camera: OrbitCamera,
    visible: Map<String, Boolean>,
    highlight: String?,
    planeSize: Float,
    solids: List<Solid>,
    outlines: List<List<V3>>,
    activeOutline: List<V3>?,
    modifier: Modifier = Modifier
) {
    val paint = remember {
        android.graphics.Paint().apply { isAntiAlias = true; textSize = 34f }
    }
    val blue = Color(0xFF3F6FBF)
    val orange = Color(0xFFE07B00)
    val partColor = Color(0xFF9FB0C8)

    Canvas(
        modifier
            .background(Color(0xFFF2F4F7))
            .onSizeChanged { camera.viewSize = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    do {
                        val ev = awaitPointerEvent()
                        val down = ev.changes.filter { it.pressed }
                        if (down.size == 1) {
                            val d = down[0].positionChange()
                            camera.yaw += d.x * 0.4f
                            camera.pitch = (camera.pitch + d.y * 0.4f).coerceIn(-89f, 89f)
                        } else if (down.size >= 2) {
                            camera.zoom = (camera.zoom * ev.calculateZoom()).coerceIn(6f, 400f)
                            val p = ev.calculatePan()
                            camera.panX += p.x; camera.panY += p.y
                        }
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        fun pr(v: V3) = camera.project(v, cx, cy)

        fun label(text: String, at: Offset, color: Color) {
            paint.color = color.toArgb()
            drawContext.canvas.nativeCanvas.drawText(text, at.x + 8f, at.y - 8f, paint)
        }

        // Rejilla sobre el plano XY
        val step = if (planeSize > 8f) 5f else 1f
        val range = 10f * step
        val grid = Color(0x22000000)
        for (i in -10..10) {
            val a = i * step
            drawLine(grid, pr(V3(a, -range, 0f)).first, pr(V3(a, range, 0f)).first, 1f)
            drawLine(grid, pr(V3(-range, a, 0f)).first, pr(V3(range, a, 0f)).first, 1f)
        }

        // Planos de referencia (de lejos a cerca)
        val s = planeSize
        val planes = PLANE_UV.filter { visible[it.first] != false }.map { (name, _) ->
            name to listOf(
                planePoint(name, -s, -s), planePoint(name, s, -s),
                planePoint(name, s, s), planePoint(name, -s, s)
            )
        }.sortedByDescending { (_, c) -> c.map { pr(it).second }.average() }
        for ((name, corners) in planes) {
            val pts = corners.map { pr(it).first }
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
                close()
            }
            val sel = name == highlight
            drawPath(path, blue.copy(alpha = if (sel) 0.30f else 0.10f), style = Fill)
            drawPath(path, blue, style = Stroke(width = if (sel) 4f else 2f))
            label(name, pts[3], blue)
        }

        // Piezas sólidas (caras ordenadas de lejos a cerca, sombreado simple)
        val faces = ArrayList<FaceDraw>()
        for (solid in solids) {
            for (f in solid.faces) {
                val pts = f.map { pr(solid.verts[it]) }
                val path = Path().apply {
                    moveTo(pts[0].first.x, pts[0].first.y)
                    for (i in 1 until pts.size) lineTo(pts[i].first.x, pts[i].first.y)
                    close()
                }
                val b = 0.55f + 0.45f * max(0f, solid.faceNormal(f).dot(LIGHT))
                faces.add(
                    FaceDraw(
                        path,
                        pts.map { it.second }.average().toFloat(),
                        Color(partColor.red * b, partColor.green * b, partColor.blue * b, 1f)
                    )
                )
            }
        }
        faces.sortByDescending { it.depth }
        for (fd in faces) {
            drawPath(fd.path, fd.fill, style = Fill)
            drawPath(fd.path, Color(0x99000000), style = Stroke(width = 2f))
        }

        // Bocetos con cotas
        fun outline(pts3: List<V3>, color: Color, width: Float) {
            val p = pts3.map { pr(it).first }
            for (i in p.indices) drawLine(color, p[i], p[(i + 1) % p.size], width)
            for (pt in p) drawCircle(color, width * 1.4f, pt)
            if (pts3.size == 4) {
                val w = (pts3[1] - pts3[0]).length()
                val h = (pts3[2] - pts3[1]).length()
                label(fmt(w), Offset((p[0].x + p[1].x) / 2f, (p[0].y + p[1].y) / 2f), Color.Black)
                label(fmt(h), Offset((p[1].x + p[2].x) / 2f, (p[1].y + p[2].y) / 2f), Color.Black)
            }
        }
        outlines.forEach { outline(it, orange, 3f) }
        activeOutline?.let { outline(it, orange, 5f) }

        // Ejes y origen
        if (visible["Origin"] != false) {
            val o = pr(V3(0f, 0f, 0f)).first
            val len = planeSize * 1.4f
            drawLine(Color.Red, o, pr(V3(len, 0f, 0f)).first, 4f)
            drawLine(Color(0xFF2E9E3E), o, pr(V3(0f, len, 0f)).first, 4f)
            drawLine(Color(0xFF1E5BFF), o, pr(V3(0f, 0f, len)).first, 4f)
            drawCircle(Color.Black, 7f, o)
        }
    }
}

private val PLANE_UV = listOf("Top" to 0, "Front" to 1, "Right" to 2)
