package com.modelo3d.studio.model

import org.json.JSONObject

/** Operación del árbol paramétrico (como el panel "Operaciones" de Onshape). */
sealed interface Op {
    val id: String
    val name: String
}

data class SketchOp(
    override val id: String,
    override val name: String,
    val plane: String,
    val x0: Float, val y0: Float,
    val w: Float, val h: Float
) : Op

data class ExtrudeOp(
    override val id: String,
    override val name: String,
    val sketchId: String,
    val depth: Float,
    val reverse: Boolean
) : Op

fun List<Op>.upserted(op: Op): List<Op> {
    val i = indexOfFirst { it.id == op.id }
    return if (i < 0) this + op else toMutableList().also { it[i] = op }
}

fun Op.toJson(): JSONObject = when (this) {
    is SketchOp -> JSONObject().put("type", "sketch").put("id", id).put("name", name)
        .put("plane", plane).put("x0", x0.toDouble()).put("y0", y0.toDouble())
        .put("w", w.toDouble()).put("h", h.toDouble())
    is ExtrudeOp -> JSONObject().put("type", "extrude").put("id", id).put("name", name)
        .put("sketchId", sketchId).put("depth", depth.toDouble()).put("reverse", reverse)
}

fun opFromJson(o: JSONObject): Op? = when (o.optString("type")) {
    "sketch" -> SketchOp(
        o.getString("id"), o.getString("name"), o.getString("plane"),
        o.getDouble("x0").toFloat(), o.getDouble("y0").toFloat(),
        o.getDouble("w").toFloat(), o.getDouble("h").toFloat()
    )
    "extrude" -> ExtrudeOp(
        o.getString("id"), o.getString("name"), o.getString("sketchId"),
        o.getDouble("depth").toFloat(), o.getBoolean("reverse")
    )
    else -> null
}
