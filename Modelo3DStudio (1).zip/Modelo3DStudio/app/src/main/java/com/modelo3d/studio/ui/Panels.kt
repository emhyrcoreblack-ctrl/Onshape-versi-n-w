package com.modelo3d.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.modelo3d.studio.model.*

private fun String.toF(): Float? = replace(',', '.').toFloatOrNull()

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

/** Panel inferior azul con ✓ y ✕, como "Boceto 1" / "Extrusión 1" en Onshape. */
@Composable
private fun PanelFrame(
    title: String,
    canConfirm: Boolean,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF1B4DB1)).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, Modifier.weight(1f), color = Color.White, style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onConfirm, enabled = canConfirm) {
                Icon(Icons.Default.Check, "Aceptar", tint = if (canConfirm) Color.White else Color(0x66FFFFFF))
            }
            IconButton(onClick = onCancel) { Icon(Icons.Default.Close, "Cancelar", tint = Color.White) }
        }
        Column(Modifier.padding(12.dp), content = content)
    }
}

@Composable
fun SketchPanel(
    draft: SketchOp,
    isNew: Boolean,
    onChange: (SketchOp) -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var x by remember(draft.id) { mutableStateOf(fmt(draft.x0)) }
    var y by remember(draft.id) { mutableStateOf(fmt(draft.y0)) }
    var w by remember(draft.id) { mutableStateOf(fmt(draft.w)) }
    var h by remember(draft.id) { mutableStateOf(fmt(draft.h)) }

    fun emit(nx: String, ny: String, nw: String, nh: String) {
        val a = nx.toF(); val b = ny.toF(); val c = nw.toF(); val d = nh.toF()
        if (a != null && b != null && c != null && d != null) {
            onChange(draft.copy(x0 = a, y0 = b, w = c, h = d))
        }
    }

    val wv = w.toF(); val hv = h.toF()
    val valid = x.toF() != null && y.toF() != null && wv != null && hv != null && wv > 0f && hv > 0f

    PanelFrame(draft.name, valid, onConfirm, onCancel, modifier) {
        Text("Plano de boceto: ${draft.plane}", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("Ancho (cm)", w, { w = it; emit(x, y, it, h) }, Modifier.weight(1f))
            NumberField("Alto (cm)", h, { h = it; emit(x, y, w, it) }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("Esquina X", x, { x = it; emit(it, y, w, h) }, Modifier.weight(1f))
            NumberField("Esquina Y", y, { y = it; emit(x, it, w, h) }, Modifier.weight(1f))
        }
        if (!isNew) TextButton(onClick = onDelete) { Text("Eliminar boceto") }
    }
}

@Composable
fun ExtrudePanel(
    draft: ExtrudeOp,
    sketchName: String,
    isNew: Boolean,
    onChange: (ExtrudeOp) -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var depth by remember(draft.id) { mutableStateOf(fmt(draft.depth)) }
    val dv = depth.toF()

    PanelFrame(draft.name, dv != null && dv > 0f, onConfirm, onCancel, modifier) {
        Text("Boceto: $sketchName", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        NumberField("Profundidad (cm)", depth, {
            depth = it
            it.toF()?.let { v -> onChange(draft.copy(depth = v)) }
        }, Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Dirección opuesta", Modifier.weight(1f))
            Switch(checked = draft.reverse, onCheckedChange = { onChange(draft.copy(reverse = it)) })
        }
        if (!isNew) TextButton(onClick = onDelete) { Text("Eliminar extrusión") }
    }
}

@Composable
fun OperationsPanel(
    ops: List<Op>,
    parts: List<Solid>,
    visible: MutableMap<String, Boolean>,
    onEdit: (Op) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier.width(280.dp)) {
        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()).padding(12.dp)) {
            Text("Geometría por defecto", style = MaterialTheme.typography.titleSmall)
            listOf("Origin", "Top", "Front", "Right").forEach { n ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f))
                    Switch(checked = visible[n] != false, onCheckedChange = { visible[n] = it })
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Operaciones (${ops.size})", style = MaterialTheme.typography.titleSmall)
            ops.forEach { op ->
                val extra = if (op is SketchOp) " · ${op.plane}" else ""
                Text(
                    op.name + extra,
                    Modifier.fillMaxWidth().clickable { onEdit(op) }.padding(vertical = 10.dp)
                )
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Piezas (${parts.size})", style = MaterialTheme.typography.titleSmall)
            parts.forEach { Text(it.name, Modifier.padding(vertical = 6.dp)) }
        }
    }
}
