package com.modelo3d.studio.viewer

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import com.modelo3d.studio.model.V3
import kotlin.math.cos
import kotlin.math.sin

class OrbitCamera {
    var yaw by mutableFloatStateOf(-35f)
    var pitch by mutableFloatStateOf(25f)
    var zoom by mutableFloatStateOf(40f)   // píxeles por unidad (cm)
    var panX by mutableFloatStateOf(0f)
    var panY by mutableFloatStateOf(0f)
    var viewSize by mutableStateOf(IntSize.Zero)

    fun setView(newYaw: Float, newPitch: Float) {
        yaw = newYaw; pitch = newPitch; panX = 0f; panY = 0f
    }

    /** Ajusta el zoom para que quepa una escena de radio [extent]. */
    fun fit(extent: Float) {
        val m = minOf(viewSize.width, viewSize.height).toFloat()
        if (m > 0f) zoom = (m * 0.45f / maxOf(extent, 1f)).coerceIn(6f, 400f)
    }

    /** Proyecta un punto 3D a pantalla. Devuelve (posición, profundidad). */
    fun project(p: V3, cx: Float, cy: Float): Pair<Offset, Float> {
        val ya = Math.toRadians(yaw.toDouble())
        val pa = Math.toRadians(pitch.toDouble())
        val cyw = cos(ya).toFloat(); val syw = sin(ya).toFloat()
        val cp = cos(pa).toFloat(); val sp = sin(pa).toFloat()
        val x1 = p.x * cyw - p.y * syw
        val y1 = p.x * syw + p.y * cyw
        val up = y1 * sp + p.z * cp
        val depth = y1 * cp - p.z * sp
        val k = CAM_DIST / (CAM_DIST + depth)
        return Offset(cx + panX + x1 * zoom * k, cy + panY - up * zoom * k) to depth
    }

    companion object { const val CAM_DIST = 120f }
}
