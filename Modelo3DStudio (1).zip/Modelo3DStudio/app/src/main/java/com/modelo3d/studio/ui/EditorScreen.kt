package com.modelo3d.studio.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.modelo3d.studio.model.*
import com.modelo3d.studio.viewer.OrbitCamera
import com.modelo3d.studio.viewer.Viewport
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

private sealed interface Mode {
    object Idle : Mode
    data class Sketching(val draft: SketchOp, val isNew: Boolean) : Mode
    data class Extruding(val draft: ExtrudeOp, val isNew: Boolean) : Mode
}

private fun newId(): String = UUID.randomUUID().toString().take(8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(project: Project, store: ProjectStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val camera = remember { OrbitCamera() }
    val doc = remember(project.id) { CadDocument(project.ops) }
    val visible = remember {
        mutableStateMapOf("Origin" to true, "Top" to true, "Front" to true, "Right" to true)
    }
    var mode by remember { mutableStateOf<Mode>(Mode.Idle) }
    var panelOpen by remember { mutableStateOf(false) }
    var pickPlane by remember { mutableStateOf(false) }

    LaunchedEffect(doc.ops) {
        project.ops = doc.ops
        store.save(project)
    }

    // Vista del modelo: el borrador en edición se aplica en vivo sobre las operaciones.
    val m = mode
    val viewOps: List<Op> = when (m) {
        is Mode.Sketching -> doc.ops.upserted(m.draft)
        is Mode.Extruding -> doc.ops.upserted(m.draft)
        Mode.Idle -> doc.ops
    }
    val solids = buildSolids(viewOps)
    val used = viewOps.filterIsInstance<ExtrudeOp>().map { it.sketchId }.toSet()
    val activeSketch = (m as? Mode.Sketching)?.draft
    val outlines = viewOps.filterIsInstance<SketchOp>()
        .filter { it.id !in used && it.id != activeSketch?.id }
        .map { sketchOutline(it) }
    val active = activeSketch?.let { sketchOutline(it) }
    val extent = sceneExtent(solids, outlines + listOfNotNull(active))
    val planeSize = max(5f, extent * 1.25f)

    fun isoFit(e: Float) {
        camera.setView(-35f, 25f)
        camera.fit(max(e, 10f))
    }

    fun viewFor(plane: String) {
        when (plane) {
            "Front" -> camera.setView(0f, 0f)
            "Top" -> camera.setView(0f, 90f)
            else -> camera.setView(-90f, 0f)
        }
        camera.fit(25f)
    }

    fun startSketch(plane: String) {
        val n = doc.ops.count { it is SketchOp } + 1
        mode = Mode.Sketching(SketchOp(newId(), "Boceto $n", plane, 0f, 0f, 20f, 15f), true)
        viewFor(plane)
    }

    fun startExtrude() {
        val usedNow = doc.ops.filterIsInstance<ExtrudeOp>().map { it.sketchId }.toSet()
        val cand = doc.ops.filterIsInstance<SketchOp>().lastOrNull { it.id !in usedNow }
        if (cand == null) {
            Toast.makeText(context, "Crea un boceto primero", Toast.LENGTH_SHORT).show()
            return
        }
        val n = doc.ops.count { it is ExtrudeOp } + 1
        mode = Mode.Extruding(ExtrudeOp(newId(), "Extrusión $n", cand.id, 5f, false), true)
        isoFit(max(extent, 20f))
    }

    fun editOp(op: Op) {
        panelOpen = false
        when (op) {
            is SketchOp -> { mode = Mode.Sketching(op, false); viewFor(op.plane) }
            is ExtrudeOp -> { mode = Mode.Extruding(op, false); isoFit(max(extent, 20f)) }
        }
    }

    val exporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(exportStl(buildSolids(doc.ops)).toByteArray())
                }
            }.isSuccess
            Toast.makeText(context, if (ok) "STL exportado (mm)" else "No se pudo exportar", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = { doc.undo() }, enabled = doc.canUndo) { Text("↶") }
                    IconButton(onClick = { doc.redo() }, enabled = doc.canRedo) { Text("↷") }
                    TextButton(onClick = { panelOpen = !panelOpen }) { Text("Operaciones") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            Viewport(
                camera = camera,
                visible = visible,
                highlight = activeSketch?.plane,
                planeSize = planeSize,
                solids = solids,
                outlines = outlines,
                activeOutline = active,
                modifier = Modifier.fillMaxSize()
            )

            if (m is Mode.Idle) {
                // Barra de herramientas
                Row(
                    Modifier.align(Alignment.TopStart).padding(8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = { pickPlane = true }) { Text("Boceto") }
                    Button(onClick = { startExtrude() }) { Text("Extruir") }
                    FilledTonalButton(onClick = { isoFit(max(extent, 10f)) }) { Text("Ajustar") }
                    FilledTonalButton(onClick = {
                        if (solids.isEmpty()) {
                            Toast.makeText(context, "No hay piezas para exportar", Toast.LENGTH_SHORT).show()
                        } else exporter.launch("${project.name}.stl")
                    }) { Text("Exportar STL") }
                }
                // Vistas estándar
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(12.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(onClick = { camera.setView(0f, 0f) }) { Text("Frente") }
                    FilledTonalButton(onClick = { camera.setView(0f, 90f) }) { Text("Arriba") }
                    FilledTonalButton(onClick = { camera.setView(-90f, 0f) }) { Text("Derecha") }
                    FilledTonalButton(onClick = { camera.setView(-35f, 25f) }) { Text("Isométrica") }
                }
            }

            if (panelOpen) {
                OperationsPanel(
                    ops = doc.ops,
                    parts = buildSolids(doc.ops),
                    visible = visible,
                    onEdit = { editOp(it) },
                    modifier = Modifier.align(Alignment.TopEnd).padding(top = 60.dp, end = 8.dp)
                )
            }

            when (m) {
                is Mode.Sketching -> SketchPanel(
                    draft = m.draft,
                    isNew = m.isNew,
                    onChange = { mode = m.copy(draft = it) },
                    onConfirm = {
                        val d = m.draft
                        doc.upsert(d)
                        mode = Mode.Idle
                        isoFit(
                            maxOf(extent, abs(d.x0), abs(d.y0), abs(d.x0 + d.w), abs(d.y0 + d.h))
                        )
                    },
                    onCancel = { mode = Mode.Idle; isoFit(extent) },
                    onDelete = { doc.delete(m.draft.id); mode = Mode.Idle; isoFit(extent) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                is Mode.Extruding -> ExtrudePanel(
                    draft = m.draft,
                    sketchName = doc.ops.firstOrNull { it.id == m.draft.sketchId }?.name ?: "",
                    isNew = m.isNew,
                    onChange = { mode = m.copy(draft = it) },
                    onConfirm = { doc.upsert(m.draft); mode = Mode.Idle; isoFit(extent) },
                    onCancel = { mode = Mode.Idle; isoFit(extent) },
                    onDelete = { doc.delete(m.draft.id); mode = Mode.Idle; isoFit(extent) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                Mode.Idle -> {}
            }
        }
    }

    if (pickPlane) {
        AlertDialog(
            onDismissRequest = { pickPlane = false },
            title = { Text("Plano de boceto") },
            text = {
                Column {
                    PLANES.forEach { p ->
                        TextButton(onClick = { pickPlane = false; startSketch(p) }) { Text(p) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickPlane = false }) { Text("Cancelar") } }
        )
    }
}
