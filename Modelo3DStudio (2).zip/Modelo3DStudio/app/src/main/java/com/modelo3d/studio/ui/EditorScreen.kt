package com.modelo3d.studio.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.modelo3d.studio.model.*
import com.modelo3d.studio.viewer.NavMode
import com.modelo3d.studio.viewer.OrbitCamera
import com.modelo3d.studio.viewer.ViewCube
import com.modelo3d.studio.viewer.Viewport
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

private sealed interface Mode {
    object Idle : Mode
    data class Sketching(val draft: SketchOp, val isNew: Boolean) : Mode
    data class Extruding(val draft: ExtrudeOp, val isNew: Boolean) : Mode
}

private fun newId(): String = UUID.randomUUID().toString().take(8)

@Composable
fun EditorScreen(project: Project, store: ProjectStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val camera = remember { OrbitCamera() }
    val doc = remember(project.id) { CadDocument(project.ops) }
    val visible = remember {
        mutableStateMapOf("Origin" to true, "Top" to true, "Front" to true, "Right" to true)
    }
    var mode by remember { mutableStateOf<Mode>(Mode.Idle) }
    var panelOpen by remember { mutableStateOf(false) }
    var pickPlane by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }
    var refsOpen by remember { mutableStateOf(false) }
    var selPlane by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(doc.ops) {
        project.ops = doc.ops
        store.save(project)
    }

    // El borrador en edición se aplica en vivo sobre las operaciones.
    val m = mode
    val viewOps: List<Op> = when (m) {
        is Mode.Sketching -> doc.ops.upserted(m.draft)
        is Mode.Extruding -> doc.ops.upserted(m.draft)
        Mode.Idle -> doc.ops
    }
    val solids = buildSolids(viewOps)
    val used = viewOps.filterIsInstance<ExtrudeOp>().map { it.sketchId }.toSet()
    val activeSketch = (m as? Mode.Sketching)?.draft
    val outlines = viewOps.filterIsInstance<SketchOp>()
        .filter { it.id !in used && it.id != activeSketch?.id }
        .map { sketchOutline(it) }
    val active = activeSketch?.let { sketchOutline(it) }
    val extent = sceneExtent(solids, outlines + listOfNotNull(active))
    val planeSize = max(5f, extent * 1.25f)

    fun isoFit(e: Float) {
        camera.setView(-35f, 25f)
        camera.fit(max(e, 10f))
    }

    fun viewFor(plane: String) {
        when (plane) {
            "Front" -> camera.setView(0f, 0f)
            "Top" -> camera.setView(0f, 90f)
            else -> camera.setView(-90f, 0f)
        }
        camera.fit(25f)
    }

    fun startSketch(plane: String) {
        val n = doc.ops.count { it is SketchOp } + 1
        mode = Mode.Sketching(SketchOp(newId(), "Boceto $n", plane, 0f, 0f, 20f, 15f), true)
        viewFor(plane)
    }

    fun startExtrude() {
        val usedNow = doc.ops.filterIsInstance<ExtrudeOp>().map { it.sketchId }.toSet()
        val cand = doc.ops.filterIsInstance<SketchOp>().lastOrNull { it.id !in usedNow }
        if (cand == null) {
            Toast.makeText(context, "Crea un boceto primero", Toast.LENGTH_SHORT).show()
            return
        }
        val n = doc.ops.count { it is ExtrudeOp } + 1
        mode = Mode.Extruding(ExtrudeOp(newId(), "Extrusión $n", cand.id, 5f, false), true)
        isoFit(max(extent, 20f))
    }

    fun editOp(op: Op) {
        panelOpen = false
        when (op) {
            is SketchOp -> { mode = Mode.Sketching(op, false); viewFor(op.plane) }
            is ExtrudeOp -> { mode = Mode.Extruding(op, false); isoFit(max(extent, 20f)) }
        }
    }

    fun saveNow() {
        project.ops = doc.ops
        store.save(project)
        Toast.makeText(context, "Proyecto guardado", Toast.LENGTH_SHORT).show()
    }

    val exporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(exportStl(buildSolids(doc.ops)).toByteArray())
                }
            }.isSuccess
            Toast.makeText(context, if (ok) "STL exportado (mm)" else "No se pudo exportar", Toast.LENGTH_LONG).show()
        }
    }

    fun exportNow() {
        if (solids.isEmpty()) {
            Toast.makeText(context, "No hay piezas para exportar", Toast.LENGTH_SHORT).show()
        } else exporter.launch("${project.name}.stl")
    }

    Column(Modifier.fillMaxSize().background(CadColors.Ink)) {

        // ---------- Cabecera ----------
        Row(
            Modifier.fillMaxWidth().background(CadColors.Panel).padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.Home, contentDescription = "Proyectos", tint = CadColors.GoldMain, modifier = Modifier.size(30.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    "NOCTURNE\nSTUDIO 3D", color = CadColors.GoldMain, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, letterSpacing = 2.sp, lineHeight = 17.sp
                )
                Text(
                    "CAD · ${project.name}".uppercase(), color = CadColors.GoldMain.copy(alpha = 0.7f),
                    fontSize = 9.sp, letterSpacing = 1.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            FrameButton(onClick = { panelOpen = !panelOpen }, modifier = Modifier.size(44.dp)) {
                CadIcon(IconKind.Menu, CadColors.GoldMain, 24.dp)
            }
            GoldButton("Guardar\nproyecto", { saveNow() }, Modifier.height(44.dp))
            FrameButton(onClick = { exportNow() }, modifier = Modifier.size(width = 48.dp, height = 44.dp)) {
                Text("STL", color = CadColors.Text, fontSize = 13.sp)
            }
        }

        // ---------- Pestañas de herramientas ----------
        val tabShape = RoundedCornerShape(14.dp)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)
                .clip(tabShape).background(CadColors.Panel).border(1.dp, CadColors.GoldSoft, tabShape)
        ) {
            ToolTab(IconKind.Cube, "Entorno", m is Mode.Idle && !panelOpen, { panelOpen = false }, Modifier.weight(1f))
            ToolTab(IconKind.Pencil, "Boceto", m is Mode.Sketching, {
                if (m is Mode.Idle) {
                    val sp = selPlane
                    if (sp != null) startSketch(sp) else pickPlane = true
                }
            }, Modifier.weight(1f))
            ToolTab(IconKind.Extrude, "Extruir", m is Mode.Extruding, {
                if (m is Mode.Idle) startExtrude()
            }, Modifier.weight(1f))
            ToolTab(IconKind.Ops, "Operaciones", panelOpen, { panelOpen = !panelOpen }, Modifier.weight(1.3f))
            Box(Modifier.weight(1f)) {
                ToolTab(IconKind.Dots, "Más", moreOpen, { moreOpen = true }, Modifier.fillMaxWidth())
                DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                    DropdownMenuItem(text = { Text("Vista isométrica") }, onClick = { moreOpen = false; camera.setView(-35f, 25f) })
                    DropdownMenuItem(text = { Text("Ajustar a pantalla") }, onClick = { moreOpen = false; isoFit(max(extent, 10f)) })
                    DropdownMenuItem(text = { Text("Guardar proyecto") }, onClick = { moreOpen = false; saveNow() })
                    DropdownMenuItem(text = { Text("Exportar STL") }, onClick = { moreOpen = false; exportNow() })
                }
            }
        }

        // ---------- Lienzo ----------
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Viewport(
                camera = camera,
                visible = visible,
                highlight = activeSketch?.plane ?: selPlane,
                planeSize = planeSize,
                solids = solids,
                outlines = outlines,
                activeOutline = active,
                modifier = Modifier.fillMaxSize()
            )

            // Riel de herramientas de navegación
            val railShape = RoundedCornerShape(14.dp)
            Column(
                Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 12.dp)
                    .clip(railShape).background(CadColors.Panel.copy(alpha = 0.92f))
                    .border(1.dp, CadColors.GoldSoft, railShape).padding(4.dp)
            ) {
                RailButton(camera.navMode == NavMode.Standard, { camera.navMode = NavMode.Standard }, kind = IconKind.Arrow)
                RailButton(false, { isoFit(max(extent, 10f)) }, kind = IconKind.Frame)
                RailButton(camera.navMode == NavMode.Pan, { camera.navMode = NavMode.Pan }, kind = IconKind.Move)
                RailButton(camera.navMode == NavMode.Orbit, { camera.navMode = NavMode.Orbit }, kind = IconKind.Rotate)
                RailButton(camera.navMode == NavMode.Zoom, { camera.navMode = NavMode.Zoom }, kind = IconKind.Zoom)
                HorizontalDivider(Modifier.padding(vertical = 4.dp), color = CadColors.GoldSoft)
                RailButton(false, { doc.undo() }, glyph = "↶", enabled = doc.canUndo)
                RailButton(false, { doc.redo() }, glyph = "↷", enabled = doc.canRedo)
            }

            // Anillo con candado + cubo de vistas
            Column(
                Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape)
                        .background(CadColors.Panel.copy(alpha = 0.85f))
                        .border(1.5.dp, if (camera.locked) CadColors.GoldMain else CadColors.GoldSoft, CircleShape)
                        .clickable { camera.locked = !camera.locked },
                    contentAlignment = Alignment.Center
                ) {
                    CadIcon(if (camera.locked) IconKind.Lock else IconKind.Unlock, CadColors.GoldMain, 26.dp)
                }
                ViewCube(camera)
            }

            if (m is Mode.Idle) {
                val dims = sizeOf(solids)
                if (dims != null) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = CadColors.Panel
                    ) {
                        Text(
                            "${fmt(dims.x)} × ${fmt(dims.y)} × ${fmt(dims.z)} cm",
                            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            color = CadColors.GoldMain, fontSize = 13.sp
                        )
                    }
                }
            }

            if (panelOpen) {
                OperationsPanel(
                    ops = doc.ops,
                    parts = buildSolids(doc.ops),
                    visible = visible,
                    onEdit = { editOp(it) },
                    modifier = Modifier.align(Alignment.TopEnd).padding(top = 196.dp, end = 8.dp)
                )
            }

            when (m) {
                is Mode.Sketching -> SketchPanel(
                    draft = m.draft,
                    isNew = m.isNew,
                    onChange = { mode = m.copy(draft = it) },
                    onConfirm = {
                        val d = m.draft
                        doc.upsert(d)
                        mode = Mode.Idle
                        isoFit(maxOf(extent, abs(d.x0), abs(d.y0), abs(d.x0 + d.w), abs(d.y0 + d.h)))
                    },
                    onCancel = { mode = Mode.Idle; isoFit(extent) },
                    onDelete = { doc.delete(m.draft.id); mode = Mode.Idle; isoFit(extent) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                is Mode.Extruding -> ExtrudePanel(
                    draft = m.draft,
                    sketchName = doc.ops.firstOrNull { it.id == m.draft.sketchId }?.name ?: "",
                    isNew = m.isNew,
                    onChange = { mode = m.copy(draft = it) },
                    onConfirm = { doc.upsert(m.draft); mode = Mode.Idle; isoFit(extent) },
                    onCancel = { mode = Mode.Idle; isoFit(extent) },
                    onDelete = { doc.delete(m.draft.id); mode = Mode.Idle; isoFit(extent) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                Mode.Idle -> {}
            }
        }

        // ---------- Barra inferior: planos de referencia ----------
        if (m is Mode.Idle) {
            Row(
                Modifier.fillMaxWidth().background(CadColors.Panel).padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val shape = RoundedCornerShape(10.dp)
                Box(Modifier.weight(1.4f)) {
                    Row(
                        Modifier.fillMaxWidth().clip(shape).background(CadColors.Panel)
                            .border(1.dp, CadColors.GoldSoft, shape)
                            .clickable { refsOpen = true }.padding(horizontal = 10.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CadIcon(IconKind.Layers, CadColors.GoldMain, 24.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Planos de referencia", Modifier.weight(1f), color = CadColors.Text, fontSize = 12.sp, maxLines = 2)
                        Text("▾", color = CadColors.GoldMain, fontSize = 14.sp)
                    }
                    DropdownMenu(expanded = refsOpen, onDismissRequest = { refsOpen = false }) {
                        listOf("Origin" to "Origen", "Top" to "Superior (XY)", "Front" to "Frontal (XZ)", "Right" to "Derecho (YZ)")
                            .forEach { (key, label) ->
                                DropdownMenuItem(
                                    text = { Text(label) },
                                    onClick = { visible[key] = visible[key] == false },
                                    leadingIcon = { Checkbox(checked = visible[key] != false, onCheckedChange = null) }
                                )
                            }
                    }
                }
                PLANES.forEach { p ->
                    PlaneChip(p, selPlane == p, { selPlane = p; viewFor(p) }, Modifier.weight(1f))
                }
            }
        }
    }

    if (pickPlane) {
        AlertDialog(
            onDismissRequest = { pickPlane = false },
            title = { Text("Plano de boceto") },
            text = {
                Column {
                    PLANES.forEach { p ->
                        TextButton(onClick = { pickPlane = false; selPlane = p; startSketch(p) }) { Text(planeLabel(p)) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickPlane = false }) { Text("Cancelar") } }
        )
    }
}
