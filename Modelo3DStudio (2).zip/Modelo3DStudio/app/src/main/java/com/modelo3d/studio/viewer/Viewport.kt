package com.modelo3d.studio.viewer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import com.modelo3d.studio.model.Solid
import com.modelo3d.studio.model.V3
import com.modelo3d.studio.model.fmt
import com.modelo3d.studio.model.planePoint
import com.modelo3d.studio.model.planeLabel
import kotlin.math.max

private val L1 = V3(-0.35f, -0.55f, 0.75f).normalized()
private val L2 = V3(0.7f, 0.2f, 0.3f).normalized()
private val PLANE_NAMES = listOf("Top", "Front", "Right")

private class FaceDraw(val path: Path, val depth: Float, val fill: Color)

/** Envolvente convexa 2D (cadena monótona), para la sombra proyectada. */
private fun hull(pts: List<Pair<Float, Float>>): List<Pair<Float, Float>> {
    val p = pts.distinct().sortedWith(compareBy<Pair<Float, Float>>({ it.first }, { it.second }))
    if (p.size < 3) return p
    fun cross(o: Pair<Float, Float>, a: Pair<Float, Float>, b: Pair<Float, Float>) =
        (a.first - o.first) * (b.second - o.second) - (a.second - o.second) * (b.first - o.first)
    val lo = ArrayList<Pair<Float, Float>>()
    for (q in p) {
        while (lo.size >= 2 && cross(lo[lo.size - 2], lo[lo.size - 1], q) <= 0f) lo.removeAt(lo.size - 1)
        lo.add(q)
    }
    val up = ArrayList<Pair<Float, Float>>()
    for (q in p.reversed()) {
        while (up.size >= 2 && cross(up[up.size - 2], up[up.size - 1], q) <= 0f) up.removeAt(up.size - 1)
        up.add(q)
    }
    lo.removeAt(lo.size - 1)
    up.removeAt(up.size - 1)
    return lo + up
}

@Composable
fun Viewport(
    camera: OrbitCamera,
    visible: Map<String, Boolean>,
    highlight: String?,
    planeSize: Float,
    solids: List<Solid>,
    outlines: List<List<V3>>,
    activeOutline: List<V3>?,
    modifier: Modifier = Modifier
) {
    val paint = remember {
        android.graphics.Paint().apply { isAntiAlias = true; textSize = 32f }
    }
    val accent = Color(0xFF6FA3E8)
    val amber = Color(0xFFD9B26A)
    val steel = Color(0xFFB4B9C4)

    Canvas(
        modifier
            .background(Brush.verticalGradient(listOf(Color(0xFF111114), Color(0xFF050506))))
            .onSizeChanged { camera.viewSize = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    do {
                        val ev = awaitPointerEvent()
                        val down = ev.changes.filter { it.pressed }
                        if (down.size == 1) {
                            val d = down[0].positionChange()
                            when (camera.navMode) {
                                NavMode.Pan -> { camera.panX += d.x; camera.panY += d.y }
                                NavMode.Zoom ->
                                    camera.zoom = (camera.zoom * (1f - d.y * 0.006f)).coerceIn(6f, 400f)
                                else -> if (!camera.locked) {
                                    camera.yaw += d.x * 0.4f
                                    camera.pitch = (camera.pitch + d.y * 0.4f).coerceIn(-89f, 89f)
                                }
                            }
                        } else if (down.size >= 2) {
                            camera.zoom = (camera.zoom * ev.calculateZoom()).coerceIn(6f, 400f)
                            val p = ev.calculatePan()
                            camera.panX += p.x; camera.panY += p.y
                        }
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        fun pr(v: V3) = camera.project(v, cx, cy)

        // Texto con halo oscuro para que se lea sobre cualquier fondo
        fun label(text: String, at: Offset, color: Color) {
            val nc = drawContext.canvas.nativeCanvas
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 7f
            paint.color = 0xE6050506.toInt()
            nc.drawText(text, at.x + 8f, at.y - 8f, paint)
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = color.toArgb()
            nc.drawText(text, at.x + 8f, at.y - 8f, paint)
        }

        // Rejilla: líneas menores y mayores
        val step = if (planeSize > 8f) 5f else 1f
        val range = 10f * step
        val minor = Color(0x14FFFFFF)
        val major = Color(0x2EFFFFFF)
        for (i in -10..10) {
            val a = i * step
            val col = if (i % 5 == 0) major else minor
            drawLine(col, pr(V3(a, -range, 0f)).first, pr(V3(a, range, 0f)).first, 1f)
            drawLine(col, pr(V3(-range, a, 0f)).first, pr(V3(range, a, 0f)).first, 1f)
        }

        // Sombra proyectada en el suelo
        for (solid in solids) {
            if (solid.verts.minOf { it.z } < -0.001f) continue
            val hp = hull(solid.verts.map { Pair(it.x + 0.47f * it.z, it.y + 0.73f * it.z) })
            if (hp.size >= 3) {
                val sp = Path()
                hp.forEachIndexed { i, q ->
                    val o = pr(V3(q.first, q.second, 0f)).first
                    if (i == 0) sp.moveTo(o.x, o.y) else sp.lineTo(o.x, o.y)
                }
                sp.close()
                drawPath(sp, Color(0x55000000), style = Fill)
            }
        }

        // Planos de referencia (de lejos a cerca)
        val s = planeSize
        val planes = PLANE_NAMES.filter { visible[it] != false }.map { name ->
            name to listOf(
                planePoint(name, -s, -s), planePoint(name, s, -s),
                planePoint(name, s, s), planePoint(name, -s, s)
            )
        }.sortedByDescending { (_, c) -> c.map { pr(it).second }.average() }
        for ((name, corners) in planes) {
            val pts = corners.map { pr(it).first }
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
                close()
            }
            val sel = name == highlight
            drawPath(path, accent.copy(alpha = if (sel) 0.30f else 0.14f), style = Fill)
            drawPath(path, accent.copy(alpha = if (sel) 0.95f else 0.55f), style = Stroke(width = if (sel) 3.5f else 1.5f))
            label(planeLabel(name), pts[3], accent)
        }

        // Piezas: iluminación con dos luces, aristas claras
        val faces = ArrayList<FaceDraw>()
        for (solid in solids) {
            for (f in solid.faces) {
                val pts = f.map { pr(solid.verts[it]) }
                val path = Path().apply {
                    moveTo(pts[0].first.x, pts[0].first.y)
                    for (i in 1 until pts.size) lineTo(pts[i].first.x, pts[i].first.y)
                    close()
                }
                val n = solid.faceNormal(f)
                val b = 0.30f + 0.55f * max(0f, n.dot(L1)) + 0.25f * max(0f, n.dot(L2))
                faces.add(
                    FaceDraw(
                        path,
                        pts.map { it.second }.average().toFloat(),
                        Color(
                            (steel.red * b).coerceIn(0f, 1f),
                            (steel.green * b).coerceIn(0f, 1f),
                            (steel.blue * b).coerceIn(0f, 1f),
                            1f
                        )
                    )
                )
            }
        }
        faces.sortByDescending { it.depth }
        for (fd in faces) {
            drawPath(fd.path, fd.fill, style = Fill)
            drawPath(fd.path, Color(0xCCEAF2FF), style = Stroke(width = 2f))
        }

        // Bocetos con cotas
        fun outline(pts3: List<V3>, color: Color, width: Float) {
            val p = pts3.map { pr(it).first }
            for (i in p.indices) drawLine(color, p[i], p[(i + 1) % p.size], width)
            for (pt in p) drawCircle(color, width * 1.4f, pt)
            if (pts3.size == 4) {
                val w = (pts3[1] - pts3[0]).length()
                val h = (pts3[2] - pts3[1]).length()
                label(fmt(w), Offset((p[0].x + p[1].x) / 2f, (p[0].y + p[1].y) / 2f), Color.White)
                label(fmt(h), Offset((p[1].x + p[2].x) / 2f, (p[1].y + p[2].y) / 2f), Color.White)
            }
        }
        outlines.forEach { outline(it, amber, 3f) }
        activeOutline?.let { outline(it, amber, 5f) }

        // Ejes con letras
        if (visible["Origin"] != false) {
            val o = pr(V3(0f, 0f, 0f)).first
            val len = planeSize * 1.4f
            val red = Color(0xFFFF5252)
            val green = Color(0xFF4CD964)
            val blue = Color(0xFF4DA3FF)
            drawLine(red.copy(alpha = 0.3f), o, pr(V3(-len, 0f, 0f)).first, 2f)
            drawLine(green.copy(alpha = 0.3f), o, pr(V3(0f, -len, 0f)).first, 2f)
            drawLine(blue.copy(alpha = 0.3f), o, pr(V3(0f, 0f, -len)).first, 2f)
            val ex = pr(V3(len, 0f, 0f)).first
            val ey = pr(V3(0f, len, 0f)).first
            val ez = pr(V3(0f, 0f, len)).first
            drawLine(red, o, ex, 4f); label("X", ex, red)
            drawLine(green, o, ey, 4f); label("Y", ey, green)
            drawLine(blue, o, ez, 4f); label("Z", ez, blue)
            drawCircle(Color.White, 7f, o)
        }
    }
}
