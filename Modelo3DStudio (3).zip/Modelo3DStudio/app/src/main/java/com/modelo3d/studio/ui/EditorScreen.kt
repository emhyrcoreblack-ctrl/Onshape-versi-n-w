package com.modelo3d.studio.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.modelo3d.studio.model.*
import com.modelo3d.studio.viewer.NavMode
import com.modelo3d.studio.viewer.OrbitCamera
import com.modelo3d.studio.viewer.ViewCube
import com.modelo3d.studio.viewer.Viewport
import java.util.UUID
import kotlin.math.max

private sealed interface Mode {
    object Idle : Mode
    data class Sketching(val draft: SketchOp, val isNew: Boolean) : Mode
    data class Extruding(val draft: ExtrudeOp, val isNew: Boolean) : Mode
}

private fun newId(): String = UUID.randomUUID().toString().take(8)

@Composable
fun EditorScreen(project: Project, store: ProjectStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val camera = remember { OrbitCamera() }
    val doc = remember(project.id) { CadDocument(project.ops) }
    val visible = remember {
        mutableStateMapOf("Origin" to true, "Top" to true, "Front" to true, "Right" to true)
    }
    val hidden = remember { mutableStateMapOf<String, Boolean>() }
    var mode by remember { mutableStateOf<Mode>(Mode.Idle) }
    var panelOpen by remember { mutableStateOf(false) }
    var pickPlane by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }
    var helpOpen by remember { mutableStateOf(false) }
    var propsOpen by remember { mutableStateOf(false) }

    // Sesión de dibujo del boceto
    var tool by remember { mutableStateOf<SketchTool?>(null) }
    var pending by remember { mutableStateOf<List<Pt>>(emptyList()) }
    var cursor by remember { mutableStateOf<Pt?>(null) }
    var catalogOpen by remember { mutableStateOf(false) }
    var dimTarget by remember { mutableStateOf<Int?>(null) }
    var lockBefore by remember { mutableStateOf(false) }

    LaunchedEffect(doc.ops) {
        project.ops = doc.ops
        store.save(project)
    }

    // El borrador en edición se aplica en vivo sobre las operaciones.
    val m = mode
    val viewOps: List<Op> = when (m) {
        is Mode.Sketching -> doc.ops.upserted(m.draft)
        is Mode.Extruding -> doc.ops.upserted(m.draft)
        Mode.Idle -> doc.ops
    }
    val allSolids = buildSolids(viewOps)
    val solids = allSolids.filter { hidden[it.opId] != true }
    val used = viewOps.filterIsInstance<ExtrudeOp>().map { it.sketchId }.toSet()
    val sk = (m as? Mode.Sketching)?.draft
    val cur = cursor

    val polysOther = viewOps.filterIsInstance<SketchOp>()
        .filter { it.id !in used && it.id != sk?.id && hidden[it.id] != true }
        .flatMap { shapePolys(it.plane, it.shapes) }
    val previews = if (sk != null) previewShapes(tool, pending, cur) else emptyList()
    val activePolys = if (sk != null) shapePolys(sk.plane, sk.shapes) else emptyList()
    val previewPolys = if (sk != null) shapePolys(sk.plane, previews) else emptyList()
    val labels = if (sk != null) shapeLabels(sk.plane, sk.shapes + previews) else emptyList()
    val cursor3 = if (sk != null && cur != null && tool != null && tool != SketchTool.Dimension) {
        planePoint(sk.plane, cur.u, cur.v, 0f)
    } else null

    val extent = sceneExtent(solids, (polysOther + activePolys + previewPolys).map { it.pts })
    val planeSize = max(5f, extent * 1.25f)

    fun isoFit(e: Float) {
        camera.setView(-35f, 25f)
        camera.fit(max(e, 10f))
    }

    fun viewFor(plane: String) {
        when (plane) {
            "Front" -> camera.setView(0f, 0f)
            "Top" -> camera.setView(0f, 90f)
            else -> camera.setView(-90f, 0f)
        }
        camera.fit(25f)
    }

    fun beginSketchSession(plane: String) {
        lockBefore = camera.locked
        camera.locked = true
        tool = null
        pending = emptyList()
        cursor = null
        dimTarget = null
        catalogOpen = true
        viewFor(plane)
    }

    fun endSketchSession() {
        camera.locked = lockBefore
        tool = null
        pending = emptyList()
        cursor = null
        dimTarget = null
        catalogOpen = false
    }

    fun startSketch(plane: String) {
        val n = doc.ops.count { it is SketchOp } + 1
        mode = Mode.Sketching(SketchOp(newId(), "Boceto $n", plane, emptyList()), true)
        beginSketchSession(plane)
    }

    fun startExtrude() {
        val usedNow = doc.ops.filterIsInstance<ExtrudeOp>().map { it.sketchId }.toSet()
        val cand = doc.ops.filterIsInstance<SketchOp>()
            .lastOrNull { it.id !in usedNow && profiles(it.shapes).isNotEmpty() }
        if (cand == null) {
            Toast.makeText(context, "Dibuja primero un perfil cerrado", Toast.LENGTH_SHORT).show()
            return
        }
        val n = doc.ops.count { it is ExtrudeOp } + 1
        mode = Mode.Extruding(ExtrudeOp(newId(), "Extrusión $n", cand.id, 5f, false), true)
        isoFit(max(extent, 20f))
    }

    fun editOp(op: Op) {
        panelOpen = false
        when (op) {
            is SketchOp -> { mode = Mode.Sketching(op, false); beginSketchSession(op.plane) }
            is ExtrudeOp -> { mode = Mode.Extruding(op, false); isoFit(max(extent, 20f)) }
        }
    }

    // Entrada táctil del dibujo: fase 0 = moviendo, fase 1 = soltó (coloca el punto)
    fun onSketchInput(phase: Int, u: Float, v: Float) {
        val md = mode as? Mode.Sketching ?: return
        val t = tool ?: return
        val draft = md.draft
        val raw = Pt(u, v)
        if (t == SketchTool.Dimension) {
            if (phase == 1) {
                val i = hitShape(draft.shapes, raw, 24f / camera.zoom)
                if (i != null) dimTarget = i
            }
            return
        }
        val p = snapPoint(raw, draft.shapes, pending, camera.zoom)
        cursor = p
        if (phase == 0) return
        val pts = pending + p
        if (pts.size >= t.needed) {
            val shape = shapeFrom(t, pts)
            if (shape != null) {
                mode = md.copy(draft = draft.copy(shapes = draft.shapes + shape))
                pending = if (t == SketchTool.Line) listOf(p) else emptyList()
            }
        } else {
            pending = pts
        }
    }

    fun saveNow() {
        project.ops = doc.ops
        store.save(project)
        Toast.makeText(context, "Proyecto guardado", Toast.LENGTH_SHORT).show()
    }

    val exporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(exportStl(buildSolids(doc.ops)).toByteArray())
                }
            }.isSuccess
            Toast.makeText(context, if (ok) "STL exportado (mm)" else "No se pudo exportar", Toast.LENGTH_LONG).show()
        }
    }

    fun exportNow() {
        if (allSolids.isEmpty()) {
            Toast.makeText(context, "No hay piezas para exportar", Toast.LENGTH_SHORT).show()
        } else exporter.launch("${project.name}.stl")
    }

    Column(Modifier.fillMaxSize().background(CadColors.Ink)) {

        // ---------- Cabecera ----------
        Row(
            Modifier.fillMaxWidth().background(CadColors.Panel).padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.Home, contentDescription = "Proyectos", tint = CadColors.GoldMain, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    project.name, color = CadColors.Text, fontSize = 20.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "NOCTURNE STUDIO 3D", color = CadColors.GoldMain.copy(alpha = 0.8f),
                    fontSize = 10.sp, letterSpacing = 2.sp
                )
            }
            IconButton(onClick = { helpOpen = true }) {
                Box(
                    Modifier.size(30.dp).clip(CircleShape).background(CadColors.GoldMain),
                    contentAlignment = Alignment.Center
                ) { Text("?", color = CadColors.OnGold, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) { Text("⋮", color = CadColors.Text, fontSize = 24.sp) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Guardar proyecto") }, onClick = { menuOpen = false; saveNow() })
                    DropdownMenuItem(text = { Text("Exportar STL") }, onClick = { menuOpen = false; exportNow() })
                }
            }
        }

        // ---------- Barra de herramientas ----------
        Row(
            Modifier.fillMaxWidth().height(52.dp).background(CadColors.PanelHi),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BarIcon(IconKind.Undo, doc.canUndo, { doc.undo() }, Modifier.weight(1f))
            BarIcon(IconKind.Redo, doc.canRedo, { doc.redo() }, Modifier.weight(1f))
            BarDivider()
            BarIcon(
                IconKind.Pencil, m !is Mode.Extruding,
                {
                    if (m is Mode.Idle) pickPlane = true
                    else if (m is Mode.Sketching) catalogOpen = !catalogOpen
                },
                Modifier.weight(1f), accent = m is Mode.Sketching
            )
            BarDivider()
            Box(Modifier.weight(1f)) {
                BarIcon(IconKind.Dots, true, { moreOpen = true }, Modifier.fillMaxWidth())
                DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                    DropdownMenuItem(text = { Text("Vista isométrica") }, onClick = { moreOpen = false; camera.setView(-35f, 25f) })
                    DropdownMenuItem(text = { Text("Ajustar a pantalla") }, onClick = { moreOpen = false; isoFit(max(extent, 10f)) })
                }
            }
            BarIcon(
                IconKind.Extrude, m is Mode.Idle, { if (m is Mode.Idle) startExtrude() },
                Modifier.weight(1f), accent = m is Mode.Extruding
            )
            BarDivider()
            BarIcon(IconKind.Clock, true, { panelOpen = !panelOpen }, Modifier.weight(1f), accent = panelOpen)
            BarIcon(IconKind.Balance, true, { propsOpen = true }, Modifier.weight(1f))
        }

        // ---------- Lienzo ----------
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Viewport(
                camera = camera,
                visible = visible,
                highlight = sk?.plane,
                planeSize = planeSize,
                solids = solids,
                polys = polysOther,
                activePolys = activePolys,
                previewPolys = previewPolys,
                labels = labels,
                cursor = cursor3,
                sketchPlane = sk?.plane,
                sketchInput = if (sk != null && tool != null) {
                    { ph: Int, u: Float, v: Float -> onSketchInput(ph, u, v) }
                } else null,
                modifier = Modifier.fillMaxSize()
            )

            // Riel de herramientas de navegación
            val railShape = RoundedCornerShape(14.dp)
            Column(
                Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 12.dp)
                    .clip(railShape).background(CadColors.Panel.copy(alpha = 0.92f))
                    .border(1.dp, CadColors.GoldSoft, railShape).padding(4.dp)
            ) {
                RailButton(camera.navMode == NavMode.Standard, { camera.navMode = NavMode.Standard }, kind = IconKind.Arrow)
                RailButton(false, { isoFit(max(extent, 10f)) }, kind = IconKind.Frame)
                RailButton(camera.navMode == NavMode.Pan, { camera.navMode = NavMode.Pan }, kind = IconKind.Move)
                RailButton(camera.navMode == NavMode.Orbit, { camera.navMode = NavMode.Orbit }, kind = IconKind.Rotate)
                RailButton(camera.navMode == NavMode.Zoom, { camera.navMode = NavMode.Zoom }, kind = IconKind.Zoom)
            }

            // Anillo con candado + cubo de vistas
            Column(
                Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape)
                        .background(CadColors.Panel.copy(alpha = 0.85f))
                        .border(1.5.dp, if (camera.locked) CadColors.GoldMain else CadColors.GoldSoft, CircleShape)
                        .clickable { camera.locked = !camera.locked },
                    contentAlignment = Alignment.Center
                ) {
                    CadIcon(if (camera.locked) IconKind.Lock else IconKind.Unlock, CadColors.GoldMain, 26.dp)
                }
                ViewCube(camera)
            }

            if (m is Mode.Idle) {
                Box(
                    Modifier.align(Alignment.BottomStart).padding(12.dp).size(54.dp).clip(CircleShape)
                        .background(CadColors.GoldMain)
                        .clickable { panelOpen = !panelOpen },
                    contentAlignment = Alignment.Center
                ) { CadIcon(IconKind.Tree, CadColors.OnGold, 28.dp) }

                val dims = sizeOf(solids)
                if (dims != null) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 78.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = CadColors.Panel
                    ) {
                        Text(
                            "${fmt(dims.x)} × ${fmt(dims.y)} × ${fmt(dims.z)} cm",
                            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            color = CadColors.GoldMain, fontSize = 13.sp
                        )
                    }
                }
            }

            if (panelOpen) {
                FeatureTree(
                    ops = doc.ops,
                    parts = allSolids,
                    visible = visible,
                    hidden = hidden,
                    onEdit = { editOp(it) },
                    onDelete = { doc.delete(it.id) },
                    onClose = { panelOpen = false },
                    modifier = Modifier.align(Alignment.TopStart)
                        .padding(start = 8.dp, top = 8.dp, bottom = 78.dp)
                        .width(300.dp).fillMaxHeight()
                )
            }

            when (m) {
                is Mode.Sketching -> SketchPanel(
                    draft = m.draft,
                    isNew = m.isNew,
                    toolName = tool?.label,
                    hint = hintFor(tool, pending.size),
                    canFinish = pending.isNotEmpty(),
                    onTools = { catalogOpen = true },
                    onUndoShape = {
                        mode = m.copy(draft = m.draft.copy(shapes = m.draft.shapes.dropLast(1)))
                        pending = emptyList()
                    },
                    onFinish = { pending = emptyList(); cursor = null },
                    onConfirm = {
                        doc.upsert(m.draft)
                        endSketchSession()
                        mode = Mode.Idle
                        isoFit(extent)
                    },
                    onCancel = { endSketchSession(); mode = Mode.Idle; isoFit(extent) },
                    onDelete = { doc.delete(m.draft.id); endSketchSession(); mode = Mode.Idle; isoFit(extent) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                is Mode.Extruding -> ExtrudePanel(
                    draft = m.draft,
                    sketchName = doc.ops.firstOrNull { it.id == m.draft.sketchId }?.name ?: "",
                    isNew = m.isNew,
                    onChange = { mode = m.copy(draft = it) },
                    onConfirm = { doc.upsert(m.draft); mode = Mode.Idle; isoFit(extent) },
                    onCancel = { mode = Mode.Idle; isoFit(extent) },
                    onDelete = { doc.delete(m.draft.id); mode = Mode.Idle; isoFit(extent) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                Mode.Idle -> {}
            }

            // Catálogo de herramientas de dibujo
            if (catalogOpen && m is Mode.Sketching) {
                ToolCatalog(
                    active = tool,
                    onPick = { t -> tool = t; pending = emptyList(); cursor = null; catalogOpen = false },
                    onSoon = { label ->
                        Toast.makeText(context, "$label: próximamente", Toast.LENGTH_SHORT).show()
                    },
                    onClose = { catalogOpen = false },
                    modifier = Modifier.align(Alignment.TopCenter).padding(8.dp)
                )
            }
        }
    }

    // Diálogo de cotas (herramienta Cota)
    val dt = dimTarget
    if (m is Mode.Sketching && dt != null && dt in m.draft.shapes.indices) {
        DimDialog(
            shape = m.draft.shapes[dt],
            onApply = { ns ->
                mode = m.copy(draft = m.draft.copy(shapes = m.draft.shapes.toMutableList().also { it[dt] = ns }))
                dimTarget = null
            },
            onDelete = {
                mode = m.copy(draft = m.draft.copy(shapes = m.draft.shapes.filterIndexed { i, _ -> i != dt }))
                dimTarget = null
            },
            onDismiss = { dimTarget = null }
        )
    }

    if (helpOpen) {
        AlertDialog(
            onDismissRequest = { helpOpen = false },
            title = { Text("Ayuda rápida") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("• Un dedo: orbitar. Dos dedos: zoom y desplazar.")
                    Text("• Lápiz: elige un plano y abre las herramientas de dibujo.")
                    Text("• Dibujar: toca o arrastra y suelta para colocar cada punto.")
                    Text("• Cota: toca un elemento para cambiar su medida o borrarlo.")
                    Text("• Cubo con marco: extruye el último boceto cerrado.")
                    Text("• Reloj o círculo dorado: árbol de operaciones y piezas.")
                    Text("• Balanza: volumen y área de las piezas.")
                    Text("• ⋮: guardar y exportar STL.")
                }
            },
            confirmButton = { TextButton(onClick = { helpOpen = false }) { Text("Entendido") } }
        )
    }

    if (propsOpen) {
        AlertDialog(
            onDismissRequest = { propsOpen = false },
            title = { Text("Propiedades") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (allSolids.isEmpty()) {
                        Text("Aún no hay piezas. Dibuja un perfil cerrado y extrúyelo.")
                    } else {
                        allSolids.forEach { sd ->
                            Text(sd.name, fontWeight = FontWeight.Bold)
                            Text("Volumen: ${fmt(volumeOf(sd))} cm³")
                            Text("Área: ${fmt(areaOf(sd))} cm²")
                        }
                        Text(
                            "Volumen total: ${fmt(allSolids.sumOf { volumeOf(it).toDouble() }.toFloat())} cm³",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { propsOpen = false }) { Text("Cerrar") } }
        )
    }

    if (pickPlane) {
        AlertDialog(
            onDismissRequest = { pickPlane = false },
            title = { Text("Plano de boceto") },
            text = {
                Column {
                    PLANES.forEach { p ->
                        TextButton(onClick = { pickPlane = false; startSketch(p) }) { Text(planeLabel(p)) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickPlane = false }) { Text("Cancelar") } }
        )
    }
}
