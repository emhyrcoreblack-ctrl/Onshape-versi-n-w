# Modelo3D Studio (Fase 1)

App CAD 3D personal para Android. Fase 1: proyectos, visor 3D táctil y planos de referencia.

## Obtener el APK desde el celular
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** > **Build APK** > **Run workflow** (también corre solo en cada push a `main`).
3. Al terminar, abre la ejecución y descarga el artefacto **Modelo3DStudio-debug**.
4. Descomprime, instala el APK (permite "instalar apps de origen desconocido").

## Controles
- Un dedo: orbitar. Dos dedos: zoom y desplazar.
- Botones inferiores: vistas Frente, Arriba, Derecha, Isométrica.
- "Operaciones": mostrar/ocultar y seleccionar planos.
