package com.modelo3d.studio.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.modelo3d.studio.model.Project
import com.modelo3d.studio.model.ProjectStore
import com.modelo3d.studio.viewer.OrbitCamera
import com.modelo3d.studio.viewer.Viewport

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(project: Project, store: ProjectStore, onBack: () -> Unit) {
    val camera = remember { OrbitCamera() }
    val visible = remember {
        mutableStateMapOf("Origin" to true, "Top" to true, "Front" to true, "Right" to true)
    }
    var selected by remember { mutableStateOf<String?>(null) }
    var panelOpen by remember { mutableStateOf(false) }

    LaunchedEffect(project.id) { store.save(project) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = { TextButton(onClick = { panelOpen = !panelOpen }) { Text("Operaciones") } }
            )
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            Viewport(camera, visible, selected, Modifier.fillMaxSize())

            // Vistas estándar
            Row(
                Modifier.align(Alignment.BottomCenter).padding(12.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(onClick = { camera.setView(0f, 0f) }) { Text("Frente") }
                FilledTonalButton(onClick = { camera.setView(0f, 90f) }) { Text("Arriba") }
                FilledTonalButton(onClick = { camera.setView(-90f, 0f) }) { Text("Derecha") }
                FilledTonalButton(onClick = { camera.setView(-35f, 25f) }) { Text("Isométrica") }
            }

            if (panelOpen) {
                Card(Modifier.align(Alignment.TopEnd).padding(8.dp).width(260.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Operaciones (0)", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        Text("Geometría por defecto", style = MaterialTheme.typography.labelLarge)
                        listOf("Origin", "Top", "Front", "Right").forEach { n ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable { selected = if (n == "Origin") null else n },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    n,
                                    Modifier.weight(1f),
                                    color = if (n == selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface
                                )
                                Switch(
                                    checked = visible[n] != false,
                                    onCheckedChange = { visible[n] = it }
                                )
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        Text("Piezas (0)", style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }
    }
}
