package com.modelo3d.studio.viewer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged

/** Plano de referencia del documento (Top, Front, Right). */
class RefPlane(val name: String, val corners: List<V3>) {
    companion object {
        private const val S = 5f
        val all = listOf(
            RefPlane("Top", listOf(V3(-S, -S, 0f), V3(S, -S, 0f), V3(S, S, 0f), V3(-S, S, 0f))),
            RefPlane("Front", listOf(V3(-S, 0f, -S), V3(S, 0f, -S), V3(S, 0f, S), V3(-S, 0f, S))),
            RefPlane("Right", listOf(V3(0f, -S, -S), V3(0f, S, -S), V3(0f, S, S), V3(0f, -S, S)))
        )
    }
}

@Composable
fun Viewport(
    camera: OrbitCamera,
    visible: Map<String, Boolean>,
    selected: String?,
    modifier: Modifier = Modifier
) {
    val paint = remember {
        android.graphics.Paint().apply { isAntiAlias = true; textSize = 34f }
    }
    val blue = Color(0xFF3F6FBF)

    Canvas(
        modifier
            .background(Color(0xFFF2F4F7))
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    do {
                        val ev = awaitPointerEvent()
                        val down = ev.changes.filter { it.pressed }
                        if (down.size == 1) {
                            val d = down[0].positionChange()
                            camera.yaw += d.x * 0.4f
                            camera.pitch = (camera.pitch + d.y * 0.4f).coerceIn(-89f, 89f)
                        } else if (down.size >= 2) {
                            camera.zoom = (camera.zoom * ev.calculateZoom()).coerceIn(6f, 400f)
                            val p = ev.calculatePan()
                            camera.panX += p.x; camera.panY += p.y
                        }
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        fun pr(v: V3) = camera.project(v, cx, cy)

        // Rejilla sobre el plano XY
        val grid = Color(0x22000000)
        for (i in -10..10) {
            drawLine(grid, pr(V3(i.toFloat(), -10f, 0f)).first, pr(V3(i.toFloat(), 10f, 0f)).first, 1f)
            drawLine(grid, pr(V3(-10f, i.toFloat(), 0f)).first, pr(V3(10f, i.toFloat(), 0f)).first, 1f)
        }

        // Planos ordenados de lejos a cerca
        val planes = RefPlane.all.filter { visible[it.name] != false }
            .sortedByDescending { pl ->
                pl.corners.map { pr(it).second }.average()
            }
        for (pl in planes) {
            val pts = pl.corners.map { pr(it).first }
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
                close()
            }
            val sel = pl.name == selected
            drawPath(path, blue.copy(alpha = if (sel) 0.35f else 0.12f), style = Fill)
            drawPath(path, blue, style = Stroke(width = if (sel) 4f else 2f))
            paint.color = blue.toArgb()
            drawContext.canvas.nativeCanvas.drawText(pl.name, pts[3].x + 12f, pts[3].y + 38f, paint)
        }

        // Ejes y origen
        if (visible["Origin"] != false) {
            val o = pr(V3(0f, 0f, 0f)).first
            drawLine(Color.Red, o, pr(V3(7f, 0f, 0f)).first, 4f)
            drawLine(Color(0xFF2E9E3E), o, pr(V3(0f, 7f, 0f)).first, 4f)
            drawLine(Color(0xFF1E5BFF), o, pr(V3(0f, 0f, 7f)).first, 4f)
            drawCircle(Color.Black, 7f, o)
        }
    }
}
