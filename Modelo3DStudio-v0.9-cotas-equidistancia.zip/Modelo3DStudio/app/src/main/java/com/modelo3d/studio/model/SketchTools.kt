package com.modelo3d.studio.model

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

private val TAU = (2.0 * PI).toFloat()

private fun normAng(x: Float): Float {
    var y = x % TAU
    if (y < 0f) y += TAU
    return y
}

private fun unitPt(x: Float, y: Float): Pt {
    val l = hypot(x, y)
    return if (l < 1e-9f) Pt(1f, 0f) else Pt(x / l, y / l)
}

/** Contorno de una curva: el punto se dibuja como una pequeña cruz. */
fun curveOutline(s: CurveS): Pair<List<Pt>, Boolean> {
    if (s.kind == "point" && s.pts.isNotEmpty()) {
        val p = s.pts[0]
        val d = 0.25f
        return listOf(Pt(p.u - d, p.v), Pt(p.u + d, p.v), p, Pt(p.u, p.v + d), Pt(p.u, p.v - d)) to false
    }
    return s.pts to s.closed
}

/** Spline de Catmull-Rom: pasa exactamente por todos los puntos. */
fun catmullRom(p: List<Pt>, closed: Boolean, perSeg: Int = 12): List<Pt> {
    val n = p.size
    if (n < 2) return p
    val out = ArrayList<Pt>()
    val segs = if (closed) n else n - 1
    fun at(i: Int): Pt = if (closed) p[((i % n) + n) % n] else p[i.coerceIn(0, n - 1)]
    for (i in 0 until segs) {
        val p0 = at(i - 1)
        val p1 = at(i)
        val p2 = at(i + 1)
        val p3 = at(i + 2)
        for (k in 0 until perSeg) {
            val t = k.toFloat() / perSeg
            val t2 = t * t
            val t3 = t2 * t
            fun cr(a: Float, b: Float, c: Float, d: Float): Float =
                0.5f * ((2f * b) + (-a + c) * t + (2f * a - 5f * b + 4f * c - d) * t2 + (-a + 3f * b - 3f * c + d) * t3)
            out.add(Pt(cr(p0.u, p1.u, p2.u, p3.u), cr(p0.v, p1.v, p2.v, p3.v)))
        }
    }
    if (!closed) out.add(p.last())
    return out
}

/** B-spline cúbico con extremos fijos: la curva sigue a los puntos de control sin pasar por ellos. */
fun bSpline(ctrl: List<Pt>, samples: Int = 16): List<Pt> {
    val n = ctrl.size
    if (n < 2) return ctrl
    val deg = min(3, n - 1)
    val m = n + deg + 1
    val knots = FloatArray(m) { i ->
        when {
            i <= deg -> 0f
            i >= n -> 1f
            else -> (i - deg).toFloat() / (n - deg)
        }
    }
    fun basis(i: Int, k: Int, t: Float): Float {
        if (k == 0) {
            val inside = t >= knots[i] && t < knots[i + 1]
            val last = t >= 1f && knots[i] < 1f && knots[i + 1] >= 1f
            return if (inside || last) 1f else 0f
        }
        var s = 0f
        val d1 = knots[i + k] - knots[i]
        if (d1 > 1e-9f) s += (t - knots[i]) / d1 * basis(i, k - 1, t)
        val d2 = knots[i + k + 1] - knots[i + 1]
        if (d2 > 1e-9f) s += (knots[i + k + 1] - t) / d2 * basis(i + 1, k - 1, t)
        return s
    }
    val count = samples * (n - 1)
    return (0..count).map { j ->
        val t = j.toFloat() / count
        var u = 0f
        var v = 0f
        for (i in 0 until n) {
            val b = basis(i, deg, t)
            u += ctrl[i].u * b
            v += ctrl[i].v * b
        }
        Pt(u, v)
    }
}

/** Dirección en la que seguiría una línea o arco que termina en [p] (null si no hay ninguno). */
private fun outgoingTangent(existing: List<Shape>, p: Pt): Pt? {
    for (s in existing) {
        when (s) {
            is LineS -> {
                if (dist(s.b, p) < 1e-3f) return unitPt(s.b.u - s.a.u, s.b.v - s.a.v)
                if (dist(s.a, p) < 1e-3f) return unitPt(s.a.u - s.b.u, s.a.v - s.b.v)
            }
            is ArcS -> {
                val cc = circumcircle(s.a, s.m, s.c) ?: continue
                val a0 = atan2(s.a.v - cc.c.v, s.a.u - cc.c.u)
                val am = atan2(s.m.v - cc.c.v, s.m.u - cc.c.u)
                val a1 = atan2(s.c.v - cc.c.v, s.c.u - cc.c.u)
                val ccw = normAng(am - a0) < normAng(a1 - a0)
                val rx = p.u - cc.c.u
                val ry = p.v - cc.c.v
                if (dist(s.c, p) < 1e-3f) return if (ccw) unitPt(-ry, rx) else unitPt(ry, -rx)
                if (dist(s.a, p) < 1e-3f) return if (ccw) unitPt(ry, -rx) else unitPt(-ry, rx)
            }
            else -> {}
        }
    }
    return null
}

/** Arco que sale de [p0] en la dirección [t] y termina en [p1]. */
private fun tangentArc(p0: Pt, p1: Pt, t: Pt): ArcS? {
    val nx = -t.v
    val ny = t.u
    val dx = p0.u - p1.u
    val dy = p0.v - p1.v
    val nd = nx * dx + ny * dy
    if (abs(nd) < 1e-6f) return null
    val s = -(dx * dx + dy * dy) / (2f * nd)
    val c = Pt(p0.u + nx * s, p0.v + ny * s)
    val r = abs(s)
    val a0 = atan2(p0.v - c.v, p0.u - c.u)
    val a1 = atan2(p1.v - c.v, p1.u - c.u)
    val sweep = if (s > 0f) normAng(a1 - a0) else -normAng(a0 - a1)
    if (abs(sweep) < 0.02f) return null
    val am = a0 + sweep / 2f
    return ArcS(p0, Pt(c.u + r * cos(am), c.v + r * sin(am)), p1)
}

private fun cleanPts(pts: List<Pt>): List<Pt> =
    pts.filterIndexed { i, q -> i == 0 || dist(q, pts[i - 1]) > 1e-4f }

/**
 * Crea las figuras de una herramienta a partir de los puntos tocados. Algunas herramientas
 * (polígonos, ranura) crean varias figuras a la vez. [sides] = lados de los polígonos y
 * [existing] = figuras del boceto (el arco tangente necesita un extremo ya dibujado).
 */
fun shapesFrom(tool: SketchTool, pts: List<Pt>, sides: Int, existing: List<Shape>): List<Shape> {
    when (tool) {
        SketchTool.Ellipse -> if (pts.size >= 3) {
            val c = pts[0]
            val a = dist(c, pts[1])
            if (a > 1e-4f) {
                val ux = (pts[1].u - c.u) / a
                val uy = (pts[1].v - c.v) / a
                val ry = abs((pts[2].u - c.u) * -uy + (pts[2].v - c.v) * ux)
                if (ry > 1e-4f) {
                    val n = 96
                    val ring = (0 until n).map { k ->
                        val t = TAU * k / n
                        val ex = a * cos(t)
                        val ey = ry * sin(t)
                        Pt(c.u + ux * ex - uy * ey, c.v + uy * ex + ux * ey)
                    }
                    return listOf(CurveS(ring, true, "ellipse"))
                }
            }
        }
        SketchTool.PolyIn, SketchTool.PolyCirc -> if (pts.size >= 2) {
            val n = sides.coerceIn(3, 64)
            val c = pts[0]
            val r = dist(c, pts[1])
            if (r > 1e-4f) {
                val phi = atan2(pts[1].v - c.v, pts[1].u - c.u)
                val half = PI.toFloat() / n
                val inscribed = tool == SketchTool.PolyIn
                val vr = if (inscribed) r else r / cos(half)
                val phi0 = if (inscribed) phi else phi - half
                val vs = (0 until n).map { k ->
                    val ang = phi0 + TAU * k / n
                    Pt(c.u + vr * cos(ang), c.v + vr * sin(ang))
                }
                return (0 until n).map { k -> LineS(vs[k], vs[(k + 1) % n]) }
            }
        }
        SketchTool.Slot -> if (pts.size >= 3) {
            val a = pts[0]
            val b = pts[1]
            val len = dist(a, b)
            if (len > 1e-4f) {
                val ux = (b.u - a.u) / len
                val uy = (b.v - a.v) / len
                val nx = -uy
                val ny = ux
                val w = abs((pts[2].u - a.u) * nx + (pts[2].v - a.v) * ny)
                if (w > 1e-4f) {
                    val a1 = Pt(a.u + nx * w, a.v + ny * w)
                    val a2 = Pt(a.u - nx * w, a.v - ny * w)
                    val b1 = Pt(b.u + nx * w, b.v + ny * w)
                    val b2 = Pt(b.u - nx * w, b.v - ny * w)
                    val endB = Pt(b.u + ux * w, b.v + uy * w)
                    val endA = Pt(a.u - ux * w, a.v - uy * w)
                    return listOf(LineS(a1, b1), ArcS(b1, endB, b2), LineS(b2, a2), ArcS(a2, endA, a1))
                }
            }
        }
        SketchTool.ArcCenter -> if (pts.size >= 3) {
            val c = pts[0]
            val r = dist(c, pts[1])
            if (r > 1e-4f && dist(c, pts[2]) > 1e-4f) {
                val a0 = atan2(pts[1].v - c.v, pts[1].u - c.u)
                val a1 = atan2(pts[2].v - c.v, pts[2].u - c.u)
                val sw = normAng(a1 - a0)
                if (sw > 0.02f && sw < TAU - 0.02f) {
                    fun at(t: Float) = Pt(c.u + r * cos(t), c.v + r * sin(t))
                    return listOf(ArcS(at(a0), at(a0 + sw / 2f), at(a0 + sw)))
                }
            }
        }
        SketchTool.ArcTangent -> if (pts.size >= 2 && dist(pts[0], pts[1]) > 1e-4f) {
            val t = outgoingTangent(existing, pts[0])
            if (t != null) {
                val arc = tangentArc(pts[0], pts[1], t)
                if (arc != null) return listOf(arc)
            }
        }
        SketchTool.Spline -> if (pts.size >= 2) {
            val closed = pts.size >= 4 && dist(pts.first(), pts.last()) < 1e-4f
            val clean = cleanPts(if (closed) pts.dropLast(1) else pts)
            if (clean.size >= 2) {
                val cl = closed && clean.size >= 3
                return listOf(CurveS(catmullRom(clean, cl), cl, "spline"))
            }
        }
        SketchTool.SplineCtl -> if (pts.size >= 2) {
            val clean = cleanPts(pts)
            if (clean.size >= 2) return listOf(CurveS(bSpline(clean), false, "spline"))
        }
        SketchTool.PointT -> if (pts.isNotEmpty()) {
            return listOf(CurveS(listOf(pts[0]), false, "point"))
        }
        else -> return listOfNotNull(shapeFrom(tool, pts))
    }
    return emptyList()
}
