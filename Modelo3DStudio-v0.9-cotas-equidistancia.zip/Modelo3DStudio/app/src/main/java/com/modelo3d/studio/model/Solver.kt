package com.modelo3d.studio.model

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Resultado de resolver el boceto: las figuras ya recolocadas, los grados de libertad que le
 * quedan y si había algo que resolver (restricciones o cotas fijas).
 */
class SolveResult(val shapes: List<Shape>, val dof: Int, val active: Boolean)

private const val MERGE_TOL = 1e-3

fun isRoundShape(s: Shape?): Boolean = s is CircleS || s is ArcS

/**
 * Solucionador de restricciones como el de Onshape: todas las restricciones y cotas se resuelven
 * a la vez (método de Gauss-Newton con jacobiano numérico) y la geometría se mueve lo menos posible
 * (paso de mínima norma ponderada). Los extremos que coinciden se tratan como un mismo punto.
 *
 * [pinShapes] = figuras de referencia que casi no se mueven; [pinPts] = puntos que se quedan donde
 * están (por ejemplo, el extremo fijo al cambiar una cota). Devuelve null si las restricciones se
 * contradicen entre sí o con las cotas.
 */
fun solveSketch(
    shapes: List<Shape>,
    cons: List<Constraint>,
    pinShapes: Set<Int> = emptySet(),
    pinPts: List<Pt> = emptyList()
): SolveResult? {
    val n = shapes.size
    val nodes = ArrayList<DoubleArray>()
    fun nodeFor(p: Pt, merge: Boolean): Int {
        if (merge) {
            for (i in nodes.indices) {
                val q = nodes[i]
                if (hypot(q[0] - p.u.toDouble(), q[1] - p.v.toDouble()) < MERGE_TOL) return i
            }
        }
        nodes.add(doubleArrayOf(p.u.toDouble(), p.v.toDouble()))
        return nodes.size - 1
    }

    // 0 = línea, 1 = círculo, 2 = arco, 3 = otra (no entra en el solucionador)
    val kind = IntArray(n) { 3 }
    val n0 = IntArray(n) { -1 }
    val n1 = IntArray(n) { -1 }
    val n2 = IntArray(n) { -1 }
    val rad = DoubleArray(n)
    val fixedF = BooleanArray(n)
    for (i in 0 until n) {
        when (val s = shapes[i]) {
            is LineS -> if (dist(s.a, s.b) > 2e-3f) {
                kind[i] = 0
                n0[i] = nodeFor(s.a, true)
                n1[i] = nodeFor(s.b, true)
                fixedF[i] = s.fixed
            }
            is CircleS -> {
                kind[i] = 1
                n0[i] = nodeFor(s.c, true)
                rad[i] = s.r.toDouble()
                fixedF[i] = s.fixed
            }
            is ArcS -> {
                kind[i] = 2
                n0[i] = nodeFor(s.a, true)
                n1[i] = nodeFor(s.m, false)
                n2[i] = nodeFor(s.c, true)
            }
            else -> {}
        }
    }

    // Componentes conectadas (por puntos compartidos y por restricciones)
    val parent = IntArray(n) { it }
    fun find(i: Int): Int {
        var x = i
        while (parent[x] != x) {
            parent[x] = parent[parent[x]]
            x = parent[x]
        }
        return x
    }
    fun union(i: Int, j: Int) { parent[find(i)] = find(j) }
    val owner = HashMap<Int, Int>()
    for (i in 0 until n) {
        if (kind[i] == 3) continue
        for (nd in intArrayOf(n0[i], n1[i], n2[i])) {
            if (nd < 0) continue
            val o = owner[nd]
            if (o != null) union(i, o) else owner[nd] = i
        }
    }
    val vc = cons.filter {
        it.a in 0 until n && kind[it.a] != 3 && (it.b < 0 || (it.b < n && kind[it.b] != 3))
    }
    for (c in vc) if (c.b >= 0) union(c.a, c.b)
    val active = HashSet<Int>()
    for (c in vc) active.add(find(c.a))
    for (i in 0 until n) if (kind[i] <= 1 && fixedF[i]) active.add(find(i))
    val inc = (0 until n).filter { kind[it] != 3 && active.contains(find(it)) }
    if (inc.isEmpty()) return SolveResult(shapes, 0, false)
    val incSet = HashSet<Int>(inc)

    // Variables: coordenadas de cada punto y radio de cada círculo
    val vidx = IntArray(nodes.size) { -1 }
    var nv = 0
    for (i in inc) {
        for (nd in intArrayOf(n0[i], n1[i], n2[i])) {
            if (nd >= 0 && vidx[nd] < 0) { vidx[nd] = nv; nv += 2 }
        }
    }
    val rvar = IntArray(n) { -1 }
    for (i in inc) if (kind[i] == 1) { rvar[i] = nv; nv += 1 }
    if (nv > 600) return null
    val x = DoubleArray(nv)
    for (nd in nodes.indices) {
        if (vidx[nd] >= 0) { x[vidx[nd]] = nodes[nd][0]; x[vidx[nd] + 1] = nodes[nd][1] }
    }
    for (i in inc) if (rvar[i] >= 0) x[rvar[i]] = rad[i]
    val x0 = x.copyOf()

    // Pesos del paso mínimo: posiciones 1, radios 1000, figuras ancladas 1e6
    val wt = DoubleArray(nv) { 1.0 }
    for (i in inc) if (rvar[i] >= 0) wt[rvar[i]] = 1e3
    for (i in pinShapes) {
        if (!incSet.contains(i)) continue
        for (nd in intArrayOf(n0[i], n1[i], n2[i])) {
            if (nd >= 0) { wt[vidx[nd]] = 1e6; wt[vidx[nd] + 1] = 1e6 }
        }
        if (rvar[i] >= 0) wt[rvar[i]] = 1e6
    }
    for (p in pinPts) {
        for (nd in nodes.indices) {
            if (vidx[nd] >= 0 && hypot(nodes[nd][0] - p.u.toDouble(), nodes[nd][1] - p.v.toDouble()) < MERGE_TOL) {
                wt[vidx[nd]] = 1e6
                wt[vidx[nd] + 1] = 1e6
            }
        }
    }

    // Cotas fijas: se mantiene la medida que tienen ahora
    val targIdx = ArrayList<Int>()
    val targVal = ArrayList<Double>()
    for (i in inc) {
        if (kind[i] == 0 && fixedF[i]) {
            val a = nodes[n0[i]]
            val b = nodes[n1[i]]
            targIdx.add(i)
            targVal.add(hypot(a[0] - b[0], a[1] - b[1]))
        }
        if (kind[i] == 1 && fixedF[i]) { targIdx.add(i); targVal.add(rad[i]) }
    }

    fun px(v: DoubleArray, nd: Int): Double = v[vidx[nd]]
    fun py(v: DoubleArray, nd: Int): Double = v[vidx[nd] + 1]
    fun isRoundK(i: Int): Boolean = kind[i] == 1 || kind[i] == 2
    fun lineLen(v: DoubleArray, i: Int): Double =
        hypot(px(v, n1[i]) - px(v, n0[i]), py(v, n1[i]) - py(v, n0[i]))
    fun endNode(i: Int, e: Int): Int = if (e == 0) n0[i] else n1[i]

    // Centro y radio de un círculo o de un arco (por 3 puntos)
    fun center(v: DoubleArray, i: Int, out: DoubleArray) {
        if (kind[i] == 1) {
            out[0] = px(v, n0[i]); out[1] = py(v, n0[i]); out[2] = v[rvar[i]]
            return
        }
        val ax = px(v, n0[i]); val ay = py(v, n0[i])
        val mx = px(v, n1[i]); val my = py(v, n1[i])
        val cx = px(v, n2[i]); val cy = py(v, n2[i])
        val d = 2.0 * (ax * (my - cy) + mx * (cy - ay) + cx * (ay - my))
        if (abs(d) < 1e-12) { out[0] = mx; out[1] = my; out[2] = 0.0; return }
        val a2 = ax * ax + ay * ay
        val b2 = mx * mx + my * my
        val c2 = cx * cx + cy * cy
        val ux = (a2 * (my - cy) + b2 * (cy - ay) + c2 * (ay - my)) / d
        val uy = (a2 * (cx - mx) + b2 * (ax - cx) + c2 * (mx - ax)) / d
        out[0] = ux; out[1] = uy; out[2] = hypot(ux - ax, uy - ay)
    }

    val ca = DoubleArray(3)
    val cb = DoubleArray(3)
    val maxM = targIdx.size + 8 * vc.size
    var cnt = 0
    fun resid(v: DoubleArray): DoubleArray {
        val out = DoubleArray(maxM)
        var k = 0
        fun put(r: Double) { out[k] = r; k++ }
        for (t in targIdx.indices) {
            val i = targIdx[t]
            if (kind[i] == 0) put(lineLen(v, i) - targVal[t]) else put(v[rvar[i]] - targVal[t])
        }
        for (c in vc) {
            val ia = c.a
            val ib = c.b
            if (!incSet.contains(ia)) continue
            if (ib >= 0 && !incSet.contains(ib)) continue
            when (c.kind) {
                CKind.Horizontal -> if (kind[ia] == 0) put(py(v, n0[ia]) - py(v, n1[ia]))
                CKind.Vertical -> if (kind[ia] == 0) put(px(v, n0[ia]) - px(v, n1[ia]))
                CKind.Parallel, CKind.Perpendicular -> if (kind[ia] == 0 && ib >= 0 && kind[ib] == 0) {
                    val dx = px(v, n1[ia]) - px(v, n0[ia])
                    val dy = py(v, n1[ia]) - py(v, n0[ia])
                    val ex = px(v, n1[ib]) - px(v, n0[ib])
                    val ey = py(v, n1[ib]) - py(v, n0[ib])
                    val la = hypot(dx, dy).coerceAtLeast(1e-9)
                    put(if (c.kind == CKind.Parallel) (dx * ey - dy * ex) / la else (dx * ex + dy * ey) / la)
                }
                CKind.Equal -> if (ib >= 0) {
                    if (kind[ia] == 0 && kind[ib] == 0) {
                        put(lineLen(v, ia) - lineLen(v, ib))
                    } else if (isRoundK(ia) && isRoundK(ib)) {
                        center(v, ia, ca); center(v, ib, cb)
                        put(ca[2] - cb[2])
                    }
                }
                CKind.Coincident -> if (kind[ia] == 0 && ib >= 0 && kind[ib] == 0) {
                    val p = endNode(ia, c.ea)
                    val q = endNode(ib, c.eb)
                    put(px(v, p) - px(v, q))
                    put(py(v, p) - py(v, q))
                }
                CKind.Concentric -> if (ib >= 0 && isRoundK(ia) && isRoundK(ib)) {
                    center(v, ia, ca); center(v, ib, cb)
                    put(ca[0] - cb[0])
                    put(ca[1] - cb[1])
                }
                CKind.Midpoint -> if (kind[ia] == 0 && ib >= 0 && kind[ib] == 0) {
                    val q = endNode(ib, c.eb)
                    put(px(v, q) - (px(v, n0[ia]) + px(v, n1[ia])) / 2.0)
                    put(py(v, q) - (py(v, n0[ia]) + py(v, n1[ia])) / 2.0)
                }
                CKind.Tangent -> if (ib >= 0) {
                    val lineI = if (kind[ia] == 0 && isRoundK(ib)) ia
                    else if (kind[ib] == 0 && isRoundK(ia)) ib else -1
                    if (lineI >= 0) {
                        val roundI = if (lineI == ia) ib else ia
                        center(v, roundI, ca)
                        val ax = px(v, n0[lineI])
                        val ay = py(v, n0[lineI])
                        val dx = px(v, n1[lineI]) - ax
                        val dy = py(v, n1[lineI]) - ay
                        val ln = hypot(dx, dy).coerceAtLeast(1e-9)
                        val sd = (dx * (ca[1] - ay) - dy * (ca[0] - ax)) / ln
                        put(abs(sd) - ca[2])
                    } else if (isRoundK(ia) && isRoundK(ib)) {
                        center(v, ia, ca); center(v, ib, cb)
                        val d = hypot(ca[0] - cb[0], ca[1] - cb[1])
                        put(if (c.ea == 0) d - (ca[2] + cb[2]) else d - abs(ca[2] - cb[2]))
                    }
                }
                CKind.Fix -> {
                    for (nd in intArrayOf(n0[ia], n1[ia], n2[ia])) {
                        if (nd >= 0) {
                            put(px(v, nd) - x0[vidx[nd]])
                            put(py(v, nd) - x0[vidx[nd] + 1])
                        }
                    }
                    if (rvar[ia] >= 0) put(v[rvar[ia]] - x0[rvar[ia]])
                }
            }
        }
        cnt = k
        return out
    }

    val first = resid(x)
    val m = cnt
    fun cut(r: DoubleArray): DoubleArray = if (r.size == m) r else r.copyOf(m)
    fun normInf(r: DoubleArray): Double {
        var mx = 0.0
        for (i in 0 until m) if (abs(r[i]) > mx) mx = abs(r[i])
        return mx
    }
    fun jac(v: DoubleArray): Array<DoubleArray> {
        val jm = Array(m) { DoubleArray(nv) }
        for (j in 0 until nv) {
            val h = 1e-6 * (1.0 + abs(v[j]))
            val orig = v[j]
            v[j] = orig + h
            val rp = resid(v)
            v[j] = orig - h
            val rm = resid(v)
            v[j] = orig
            for (i in 0 until m) jm[i][j] = (rp[i] - rm[i]) / (2.0 * h)
        }
        return jm
    }

    var r = cut(first)
    for (iter in 0 until 80) {
        if (normInf(r) < 1e-7) break
        val jm = jac(x)
        val a = Array(m) { DoubleArray(m) }
        for (i in 0 until m) {
            for (j in i until m) {
                var s = 0.0
                for (k in 0 until nv) s += jm[i][k] * jm[j][k] / wt[k]
                a[i][j] = s
                a[j][i] = s
            }
            a[i][i] += 1e-9
        }
        val y = linSolve(a, DoubleArray(m) { -r[it] })
        val dx = DoubleArray(nv) { k ->
            var s = 0.0
            for (i in 0 until m) s += jm[i][k] * y[i]
            s / wt[k]
        }
        var step = 1.0
        val base = normInf(r)
        var xn = DoubleArray(nv)
        var rn = r
        for (t in 0 until 8) {
            xn = DoubleArray(nv) { x[it] + step * dx[it] }
            rn = cut(resid(xn))
            if (normInf(rn) < base || base < 1e-12) break
            step /= 2.0
        }
        xn.copyInto(x)
        r = rn
    }
    var ok = normInf(r) < 5e-4

    // Que ninguna línea o círculo se aplaste hasta un punto
    if (ok) {
        for (i in inc) {
            if (kind[i] == 0) {
                val orig = hypot(nodes[n0[i]][0] - nodes[n1[i]][0], nodes[n0[i]][1] - nodes[n1[i]][1])
                if (lineLen(x, i) < 1e-3 && orig >= 1e-3) ok = false
            }
            if (kind[i] == 1 && x[rvar[i]] < 1e-3 && rad[i] >= 1e-3) ok = false
        }
    }
    if (!ok) return null

    val dof = nv - rankOf(jac(x), nv)
    val out = shapes.toMutableList()
    for (i in inc) {
        when (kind[i]) {
            0 -> {
                val s = shapes[i] as LineS
                out[i] = s.copy(
                    a = Pt(px(x, n0[i]).toFloat(), py(x, n0[i]).toFloat()),
                    b = Pt(px(x, n1[i]).toFloat(), py(x, n1[i]).toFloat())
                )
            }
            1 -> {
                val s = shapes[i] as CircleS
                out[i] = s.copy(c = Pt(px(x, n0[i]).toFloat(), py(x, n0[i]).toFloat()), r = x[rvar[i]].toFloat())
            }
            2 -> out[i] = ArcS(
                Pt(px(x, n0[i]).toFloat(), py(x, n0[i]).toFloat()),
                Pt(px(x, n1[i]).toFloat(), py(x, n1[i]).toFloat()),
                Pt(px(x, n2[i]).toFloat(), py(x, n2[i]).toFloat())
            )
        }
    }
    return SolveResult(out, dof, true)
}

/** Texto de estado del boceto (null si no tiene restricciones ni cotas). */
fun sketchStatus(shapes: List<Shape>, cons: List<Constraint>): String? {
    val r = solveSketch(shapes, cons) ?: return "Restricciones en conflicto"
    if (!r.active) return null
    return if (r.dof <= 0) "Totalmente definido" else "Grados de libertad: ${r.dof}"
}

private fun linSolve(a: Array<DoubleArray>, b: DoubleArray): DoubleArray {
    val n = b.size
    val mat = Array(n) { i -> DoubleArray(n + 1) { j -> if (j < n) a[i][j] else b[i] } }
    for (c in 0 until n) {
        var p = c
        for (r in c + 1 until n) if (abs(mat[r][c]) > abs(mat[p][c])) p = r
        if (abs(mat[p][c]) < 1e-14) continue
        val tmp = mat[c]
        mat[c] = mat[p]
        mat[p] = tmp
        for (r in c + 1 until n) {
            val f = mat[r][c] / mat[c][c]
            if (f != 0.0) for (k in c..n) mat[r][k] -= f * mat[c][k]
        }
    }
    val y = DoubleArray(n)
    for (r in n - 1 downTo 0) {
        if (abs(mat[r][r]) < 1e-14) { y[r] = 0.0; continue }
        var s = mat[r][n]
        for (k in r + 1 until n) s -= mat[r][k] * y[k]
        y[r] = s / mat[r][r]
    }
    return y
}

private fun rankOf(j: Array<DoubleArray>, nv: Int): Int {
    val rows = j.size
    if (rows == 0) return 0
    var scale = 0.0
    for (row in j) for (v in row) if (abs(v) > scale) scale = abs(v)
    if (scale == 0.0) return 0
    val used = BooleanArray(rows)
    val mat = Array(rows) { j[it].copyOf() }
    var rank = 0
    for (c in 0 until nv) {
        var p = -1
        var best = 0.0
        for (i in 0 until rows) {
            if (!used[i] && abs(mat[i][c]) > best) { best = abs(mat[i][c]); p = i }
        }
        if (p < 0 || best < 1e-6 * scale) continue
        used[p] = true
        rank++
        for (i in 0 until rows) {
            if (i != p && mat[i][c] != 0.0) {
                val f = mat[i][c] / mat[p][c]
                for (k in c until nv) mat[i][k] -= f * mat[p][k]
            }
        }
    }
    return rank
}
