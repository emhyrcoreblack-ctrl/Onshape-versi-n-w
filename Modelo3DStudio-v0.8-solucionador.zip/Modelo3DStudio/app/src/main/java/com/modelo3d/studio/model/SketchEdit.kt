package com.modelo3d.studio.model

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Resultado de una edición del boceto (recortar, extender, equidistancia, redondeo, chaflán). */
class EditResult(val shapes: List<Shape>, val cons: List<Constraint>, val error: String? = null)

private fun fail(shapes: List<Shape>, cons: List<Constraint>, msg: String) = EditResult(shapes, cons, msg)

private fun endPt(l: LineS, e: Int): Pt = if (e == 0) l.a else l.b

private fun lerp(a: Pt, b: Pt, t: Float) = Pt(a.u + (b.u - a.u) * t, a.v + (b.v - a.v) * t)

/** Los 4 lados de un rectángulo como líneas: abajo, derecha, arriba, izquierda. */
fun rectLines(r: RectS): List<LineS> {
    val p0 = Pt(r.x, r.y)
    val p1 = Pt(r.x + r.w, r.y)
    val p2 = Pt(r.x + r.w, r.y + r.h)
    val p3 = Pt(r.x, r.y + r.h)
    return listOf(LineS(p0, p1), LineS(p1, p2), LineS(p2, p3), LineS(p3, p0))
}

/** Parámetro t (sobre a→b) donde a→b cruza el segmento c→d; null si no se cruzan. */
private fun segParam(a: Pt, b: Pt, c: Pt, d: Pt): Float? {
    val rx = b.u - a.u
    val ry = b.v - a.v
    val sx = d.u - c.u
    val sy = d.v - c.v
    val den = rx * sy - ry * sx
    if (abs(den) < 1e-9f) return null
    val qx = c.u - a.u
    val qy = c.v - a.v
    val t = (qx * sy - qy * sx) / den
    val u = (qx * ry - qy * rx) / den
    return if (u >= -1e-4f && u <= 1f + 1e-4f) t else null
}

/** Parámetros t (sobre a→b) donde a→b cruza la circunferencia de centro c y radio r. */
private fun circParams(a: Pt, b: Pt, c: Pt, r: Float): List<Float> {
    val rx = b.u - a.u
    val ry = b.v - a.v
    val fx = a.u - c.u
    val fy = a.v - c.v
    val qa = rx * rx + ry * ry
    val qb = 2f * (fx * rx + fy * ry)
    val qc = fx * fx + fy * fy - r * r
    val disc = qb * qb - 4f * qa * qc
    if (qa < 1e-12f || disc < 0f) return emptyList()
    val sq = sqrt(disc)
    return listOf((-qb - sq) / (2f * qa), (-qb + sq) / (2f * qa))
}

/** Cruces de la recta a→b con todas las demás figuras (menos la [skip]). */
private fun crossParams(shapes: List<Shape>, skip: Int, a: Pt, b: Pt): List<Float> {
    val out = ArrayList<Float>()
    shapes.forEachIndexed { i, s ->
        if (i == skip) return@forEachIndexed
        when (s) {
            is LineS -> segParam(a, b, s.a, s.b)?.let { out.add(it) }
            is RectS -> rectLines(s).forEach { l -> segParam(a, b, l.a, l.b)?.let { out.add(it) } }
            is CircleS -> out.addAll(circParams(a, b, s.c, s.r))
            is ArcS -> polyParams(a, b, arcPoints(s), false, out)
            is CurveS -> {
                val o = curveOutline(s)
                polyParams(a, b, o.first, o.second, out)
            }
        }
    }
    return out
}

/** Recortar: quita de la línea tocada el tramo entre los cruces más cercanos al punto [p]. */
fun trimAt(shapes: List<Shape>, cons: List<Constraint>, idx: Int, p: Pt): EditResult {
    var list: List<Shape> = shapes
    val target = list.getOrNull(idx) ?: return fail(shapes, cons, "No hay nada que recortar ahí")
    if (target is RectS) {
        val lines = rectLines(target)
        var e = 0
        var bd = Float.MAX_VALUE
        lines.forEachIndexed { k, l ->
            val d = distToSeg(p, l.a, l.b)
            if (d < bd) { bd = d; e = k }
        }
        val m = list.toMutableList()
        m[idx] = lines[e]
        lines.forEachIndexed { k, l -> if (k != e) m.add(l) }
        list = m
    }
    val ln = list[idx] as? LineS ?: return fail(shapes, cons, "Recortar funciona con líneas y rectángulos")
    val len = dist(ln.a, ln.b)
    if (len < 1e-6f) return fail(shapes, cons, "La línea es demasiado corta")
    val ts = crossParams(list, idx, ln.a, ln.b).filter { it > 1e-4f && it < 1f - 1e-4f }.sorted()
    val tp = ((p.u - ln.a.u) * (ln.b.u - ln.a.u) + (p.v - ln.a.v) * (ln.b.v - ln.a.v)) / (len * len)
    val left = ts.lastOrNull { it < tp }
    val right = ts.firstOrNull { it > tp }
    if (left == null && right == null) {
        val rm = removeShapeAt(list, cons, idx)
        return EditResult(rm.first, rm.second)
    }
    val newCons = clearConstraintsOf(cons, idx)
    val m = list.toMutableList()
    if (left != null && right != null) {
        m[idx] = ln.copy(b = lerp(ln.a, ln.b, left), fixed = false)
        m.add(LineS(lerp(ln.a, ln.b, right), ln.b))
    } else if (right != null) {
        m[idx] = ln.copy(a = lerp(ln.a, ln.b, right), fixed = false)
    } else if (left != null) {
        m[idx] = ln.copy(b = lerp(ln.a, ln.b, left), fixed = false)
    }
    return EditResult(m, newCons)
}

/** Extender: alarga el extremo de la línea más cercano a [p] hasta la figura siguiente. */
fun extendEnd(shapes: List<Shape>, cons: List<Constraint>, idx: Int, p: Pt): EditResult {
    val ln = shapes.getOrNull(idx) as? LineS ?: return fail(shapes, cons, "Extender funciona con líneas")
    val atB = dist(p, ln.b) <= dist(p, ln.a)
    val from = if (atB) ln.b else ln.a
    val other = if (atB) ln.a else ln.b
    if (dist(from, other) < 1e-6f) return fail(shapes, cons, "La línea es demasiado corta")
    val t = crossParams(shapes, idx, other, from).filter { it > 1f + 1e-4f }.minOrNull()
        ?: return fail(shapes, cons, "No hay nada hacia donde extender")
    val np = lerp(other, from, t)
    val m = shapes.toMutableList()
    m[idx] = if (atB) ln.copy(b = np, fixed = false) else ln.copy(a = np, fixed = false)
    return EditResult(m, clearConstraintsOf(cons, idx))
}

/** Equidistancia: copia la figura [idx] a la distancia [d], del lado donde está el punto [side]. */
fun offsetShape(shapes: List<Shape>, cons: List<Constraint>, idx: Int, d: Float, side: Pt): EditResult {
    if (d <= 1e-4f) return fail(shapes, cons, "La distancia debe ser mayor que cero")
    val made: Shape = when (val s = shapes.getOrNull(idx)) {
        is LineS -> {
            val len = dist(s.a, s.b)
            if (len < 1e-6f) return fail(shapes, cons, "La línea es demasiado corta")
            val nx = -(s.b.v - s.a.v) / len
            val ny = (s.b.u - s.a.u) / len
            val sg = if ((side.u - s.a.u) * nx + (side.v - s.a.v) * ny >= 0f) 1f else -1f
            LineS(
                Pt(s.a.u + nx * d * sg, s.a.v + ny * d * sg),
                Pt(s.b.u + nx * d * sg, s.b.v + ny * d * sg)
            )
        }
        is CircleS -> {
            val r2 = if (dist(side, s.c) >= s.r) s.r + d else s.r - d
            if (r2 <= 1e-4f) return fail(shapes, cons, "La equidistancia hacia adentro es demasiado grande")
            CircleS(s.c, r2)
        }
        is RectS -> {
            val inside = side.u >= s.x && side.u <= s.x + s.w && side.v >= s.y && side.v <= s.y + s.h
            val k = if (inside) -d else d
            val w2 = s.w + 2f * k
            val h2 = s.h + 2f * k
            if (w2 <= 1e-4f || h2 <= 1e-4f) return fail(shapes, cons, "La equidistancia hacia adentro es demasiado grande")
            RectS(s.x - k, s.y - k, w2, h2)
        }
        is ArcS -> return fail(shapes, cons, "La equidistancia de arcos todavía no está lista")
        is CurveS -> return fail(shapes, cons, "La equidistancia de curvas todavía no está lista")
        null -> return fail(shapes, cons, "No hay nada que copiar ahí")
    }
    return EditResult(shapes + made, cons)
}

/**
 * Redondeo ([round] = true, [amount] = radio) o chaflán ([round] = false, [amount] = distancia
 * desde la esquina sobre cada línea) en la esquina que comparten dos líneas.
 */
fun cornerCut(
    shapes: List<Shape>, cons: List<Constraint>, i1: Int, i2: Int, amount: Float, round: Boolean
): EditResult {
    val l1 = shapes.getOrNull(i1) as? LineS
    val l2 = shapes.getOrNull(i2) as? LineS
    if (l1 == null || l2 == null || i1 == i2) {
        return fail(shapes, cons, "Toca dos líneas que se unan en una esquina")
    }
    if (amount <= 1e-4f) return fail(shapes, cons, "La medida debe ser mayor que cero")
    var corner: Pt? = null
    var e1 = 0
    var e2 = 0
    for (a in 0..1) for (b in 0..1) {
        if (corner == null && dist(endPt(l1, a), endPt(l2, b)) < 1e-3f) {
            corner = endPt(l1, a); e1 = a; e2 = b
        }
    }
    val c = corner ?: return fail(shapes, cons, "Las dos líneas deben compartir una esquina")
    val f1 = endPt(l1, 1 - e1)
    val f2 = endPt(l2, 1 - e2)
    val len1 = dist(c, f1)
    val len2 = dist(c, f2)
    if (len1 < 1e-6f || len2 < 1e-6f) return fail(shapes, cons, "Una de las líneas es demasiado corta")
    val d1 = Pt((f1.u - c.u) / len1, (f1.v - c.v) / len1)
    val d2 = Pt((f2.u - c.u) / len2, (f2.v - c.v) / len2)
    val cosT = (d1.u * d2.u + d1.v * d2.v).coerceIn(-1f, 1f)
    val theta = acos(cosT)
    if (theta < 0.02f || theta > PI.toFloat() - 0.02f) {
        return fail(shapes, cons, "Las líneas están casi alineadas; no hay esquina")
    }
    val t = if (round) amount / tan(theta / 2f) else amount
    if (t >= len1 - 1e-3f || t >= len2 - 1e-3f) {
        return fail(shapes, cons, "La medida es demasiado grande para estas líneas")
    }
    val t1 = Pt(c.u + d1.u * t, c.v + d1.v * t)
    val t2 = Pt(c.u + d2.u * t, c.v + d2.v * t)
    val extra: Shape = if (round) {
        val bu = d1.u + d2.u
        val bv = d1.v + d2.v
        val bl = sqrt(bu * bu + bv * bv)
        val bis = Pt(bu / bl, bv / bl)
        val toCenter = amount / sin(theta / 2f)
        val o = Pt(c.u + bis.u * toCenter, c.v + bis.v * toCenter)
        val mid = Pt(o.u - bis.u * amount, o.v - bis.v * amount)
        ArcS(t1, mid, t2)
    } else LineS(t1, t2)
    val m = shapes.toMutableList()
    m[i1] = if (e1 == 0) l1.copy(a = t1, fixed = false) else l1.copy(b = t1, fixed = false)
    m[i2] = if (e2 == 0) l2.copy(a = t2, fixed = false) else l2.copy(b = t2, fixed = false)
    m.add(extra)
    val base = clearConstraintsOf(clearConstraintsOf(cons, i1), i2)
    val withTan = if (round) {
        base + Constraint(CKind.Tangent, i1, m.lastIndex) + Constraint(CKind.Tangent, i2, m.lastIndex)
    } else base
    return EditResult(m, withTan)
}

// ---------------------------------------------------------------------------
// Partir, simetría, patrones y mover
// ---------------------------------------------------------------------------

private fun polyParams(a: Pt, b: Pt, pts: List<Pt>, closed: Boolean, out: MutableList<Float>) {
    val n = pts.size
    val segs = if (closed) n else n - 1
    for (k in 0 until segs) segParam(a, b, pts[k], pts[(k + 1) % n])?.let { out.add(it) }
}

/** Copia de la figura transformada con [f]. Los rectángulos pasan a ser 4 líneas. */
private fun mapShape(s: Shape, f: (Pt) -> Pt): List<Shape> = when (s) {
    is LineS -> listOf(LineS(f(s.a), f(s.b)))
    is RectS -> rectLines(s).map { LineS(f(it.a), f(it.b)) }
    is CircleS -> listOf(CircleS(f(s.c), s.r))
    is ArcS -> listOf(ArcS(f(s.a), f(s.m), f(s.c)))
    is CurveS -> listOf(CurveS(s.pts.map(f), s.closed, s.kind))
}

private fun translateShape(s: Shape, dx: Float, dy: Float): Shape {
    fun mv(p: Pt) = Pt(p.u + dx, p.v + dy)
    return when (s) {
        is LineS -> s.copy(a = mv(s.a), b = mv(s.b))
        is RectS -> s.copy(x = s.x + dx, y = s.y + dy)
        is CircleS -> s.copy(c = mv(s.c))
        is ArcS -> ArcS(mv(s.a), mv(s.m), mv(s.c))
        is CurveS -> CurveS(s.pts.map { mv(it) }, s.closed, s.kind)
    }
}

/** Parte la figura [idx] en el punto tocado (o en el cruce más cercano si hay uno a mano). */
fun splitAt(shapes: List<Shape>, cons: List<Constraint>, idx: Int, p: Pt, tol: Float): EditResult {
    var list: List<Shape> = shapes
    val first = list.getOrNull(idx) ?: return fail(shapes, cons, "No hay nada que partir ahí")
    if (first is RectS) {
        val lines = rectLines(first)
        var e = 0
        var bd = Float.MAX_VALUE
        lines.forEachIndexed { k, l ->
            val d = distToSeg(p, l.a, l.b)
            if (d < bd) { bd = d; e = k }
        }
        val m = list.toMutableList()
        m[idx] = lines[e]
        lines.forEachIndexed { k, l -> if (k != e) m.add(l) }
        list = m
    }
    val newCons = clearConstraintsOf(cons, idx)
    return when (val s = list[idx]) {
        is LineS -> {
            val len = dist(s.a, s.b)
            if (len < 1e-6f) return fail(shapes, cons, "La línea es demasiado corta")
            val tp = ((p.u - s.a.u) * (s.b.u - s.a.u) + (p.v - s.a.v) * (s.b.v - s.a.v)) / (len * len)
            val inter = crossParams(list, idx, s.a, s.b)
                .filter { it > 1e-4f && it < 1f - 1e-4f }
                .minByOrNull { abs(it - tp) }
            val t = if (inter != null && abs(inter - tp) * len < tol) inter else tp
            if (t < 0.02f || t > 0.98f) return fail(shapes, cons, "Toca más lejos del extremo de la línea")
            val q = lerp(s.a, s.b, t)
            val m = list.toMutableList()
            m[idx] = s.copy(b = q, fixed = false)
            m.add(LineS(q, s.b))
            EditResult(m, newCons)
        }
        is ArcS -> {
            val pts = arcPoints(s)
            val n = pts.size - 1
            var k = 0
            var bd = Float.MAX_VALUE
            for (j in pts.indices) {
                val d = dist(p, pts[j])
                if (d < bd) { bd = d; k = j }
            }
            if (k < 2 || k > n - 2) return fail(shapes, cons, "Toca más lejos del extremo del arco")
            val q = pts[k]
            val m = list.toMutableList()
            m[idx] = ArcS(s.a, pts[k / 2], q)
            m.add(ArcS(q, pts[(k + n) / 2], s.c))
            EditResult(m, newCons)
        }
        is CircleS -> {
            val d = dist(p, s.c)
            if (d < 1e-6f) return fail(shapes, cons, "Toca sobre la circunferencia")
            val ux = (p.u - s.c.u) / d
            val uy = (p.v - s.c.v) / d
            val q1 = Pt(s.c.u + ux * s.r, s.c.v + uy * s.r)
            val q2 = Pt(s.c.u - ux * s.r, s.c.v - uy * s.r)
            val m1 = Pt(s.c.u - uy * s.r, s.c.v + ux * s.r)
            val m2 = Pt(s.c.u + uy * s.r, s.c.v - ux * s.r)
            val m = list.toMutableList()
            m[idx] = ArcS(q1, m1, q2)
            m.add(ArcS(q2, m2, q1))
            EditResult(m, newCons)
        }
        else -> fail(shapes, cons, "Partir funciona con líneas, arcos, círculos y rectángulos")
    }
}

/** Copia en espejo de la figura [idx] respecto a la línea [axisIdx]. */
fun mirrorShape(shapes: List<Shape>, cons: List<Constraint>, idx: Int, axisIdx: Int): EditResult {
    val s = shapes.getOrNull(idx) ?: return fail(shapes, cons, "No hay nada que copiar ahí")
    val ax = shapes.getOrNull(axisIdx) as? LineS ?: return fail(shapes, cons, "El eje debe ser una línea")
    val len = dist(ax.a, ax.b)
    if (len < 1e-6f) return fail(shapes, cons, "El eje es demasiado corto")
    val ux = (ax.b.u - ax.a.u) / len
    val uy = (ax.b.v - ax.a.v) / len
    val f = { p: Pt ->
        val along = (p.u - ax.a.u) * ux + (p.v - ax.a.v) * uy
        val fx = ax.a.u + ux * along
        val fy = ax.a.v + uy * along
        Pt(2f * fx - p.u, 2f * fy - p.v)
    }
    return EditResult(shapes + mapShape(s, f), cons)
}

/** Patrón lineal: [count] figuras en total, separadas [spacing] hacia el punto [dirPt]. */
fun linearPattern(
    shapes: List<Shape>, cons: List<Constraint>, idx: Int, dirPt: Pt, spacing: Float, count: Int
): EditResult {
    val s = shapes.getOrNull(idx) ?: return fail(shapes, cons, "No hay nada que repetir ahí")
    if (spacing <= 1e-4f) return fail(shapes, cons, "La distancia debe ser mayor que cero")
    val ref = outline2D(s).first.firstOrNull() ?: return fail(shapes, cons, "Figura no válida")
    val dx = dirPt.u - ref.u
    val dy = dirPt.v - ref.v
    val l = dist(dirPt, ref)
    if (l < 1e-6f) return fail(shapes, cons, "Toca un punto distinto para dar la dirección")
    val out = ArrayList<Shape>(shapes)
    for (k in 1 until count.coerceAtLeast(2)) {
        out.add(translateShape(s, dx / l * spacing * k, dy / l * spacing * k))
    }
    return EditResult(out, cons)
}

/** Patrón circular: [count] figuras en total repartidas en 360° alrededor de [center]. */
fun circularPattern(
    shapes: List<Shape>, cons: List<Constraint>, idx: Int, center: Pt, count: Int
): EditResult {
    val s = shapes.getOrNull(idx) ?: return fail(shapes, cons, "No hay nada que repetir ahí")
    val n = count.coerceAtLeast(2)
    val out = ArrayList<Shape>(shapes)
    for (k in 1 until n) {
        val ang = (2.0 * PI).toFloat() * k / n
        val cs = kotlin.math.cos(ang)
        val sn = kotlin.math.sin(ang)
        val f = { p: Pt ->
            val dx = p.u - center.u
            val dy = p.v - center.v
            Pt(center.u + dx * cs - dy * sn, center.v + dx * sn + dy * cs)
        }
        out.addAll(mapShape(s, f))
    }
    return EditResult(out, cons)
}

/** Mueve la figura [idx] (dx, dy). Sus restricciones se quitan porque ya no valdrían. */
fun moveShape(shapes: List<Shape>, cons: List<Constraint>, idx: Int, dx: Float, dy: Float): EditResult {
    val s = shapes.getOrNull(idx) ?: return fail(shapes, cons, "No hay nada que mover ahí")
    if (abs(dx) < 1e-6f && abs(dy) < 1e-6f) return fail(shapes, cons, "El punto de llegada es el mismo")
    val m = shapes.toMutableList()
    m[idx] = translateShape(s, dx, dy)
    return EditResult(m, clearConstraintsOf(cons, idx))
}
